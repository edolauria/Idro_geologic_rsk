/**
 * RiskMap TO — Electron Main Process
 * Avvia l'applicazione come app desktop nativa
 * 
 * Architettura:
 * - Avvia il server Express (server.js) come processo figlio
 * - Apre una finestra BrowserWindow puntando a http://localhost:3000
 * - Gestisce le API Anthropic tramite proxy locale (nessun CORS)
 */

const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');

let mainWindow;
let serverProcess;
const PORT = 3000;

// ─── Avvia il server Express ───────────────────────────────────────────────
function startServer() {
  return new Promise((resolve, reject) => {
    const serverPath = path.join(__dirname, '..', 'server.js');
    
    serverProcess = spawn(process.execPath, [serverPath], {
      env: { ...process.env, PORT: PORT.toString() },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    serverProcess.stdout.on('data', (data) => {
      const msg = data.toString();
      console.log('[Server]', msg);
      if (msg.includes('Server attivo')) resolve();
    });

    serverProcess.stderr.on('data', (data) => {
      console.error('[Server Error]', data.toString());
    });

    serverProcess.on('error', (err) => {
      console.error('Impossibile avviare il server:', err);
      reject(err);
    });

    // Timeout di sicurezza
    setTimeout(resolve, 3000);
  });
}

// ─── Attendi che il server risponda ───────────────────────────────────────
function waitForServer(maxAttempts = 20) {
  return new Promise((resolve, reject) => {
    let attempts = 0;
    const check = () => {
      const req = http.get(`http://localhost:${PORT}`, (res) => {
        resolve();
      });
      req.on('error', () => {
        attempts++;
        if (attempts >= maxAttempts) {
          reject(new Error('Server non risponde'));
        } else {
          setTimeout(check, 300);
        }
      });
      req.end();
    };
    check();
  });
}

// ─── Crea la finestra principale ──────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'RiskMap TO — Rischio Idrogeologico Provincia di Torino',
    backgroundColor: '#0f1117',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    // Icona (generata se non presente)
    // icon: path.join(__dirname, '..', 'assets', 'icon.png'),
  });

  // Mostra loading mentre il server si avvia
  mainWindow.loadFile(path.join(__dirname, 'loading.html'));

  // Menu nativo
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: '🔑 Configura API Key Anthropic…',
          accelerator: 'CmdOrCtrl+K',
          click: () => {
            mainWindow.webContents.executeJavaScript('document.getElementById("api-key-modal") && (document.getElementById("api-key-modal").style.display="flex")');
          }
        },
        { type: 'separator' },
        { label: '🗺 Mappa', click: () => mainWindow.webContents.executeJavaScript('switchView("mappa")') },
        { label: '📋 Comuni', click: () => mainWindow.webContents.executeJavaScript('switchView("comuni")') },
        { label: '📊 Analisi', click: () => mainWindow.webContents.executeJavaScript('switchView("analisi")') },
        { type: 'separator' },
        { role: 'quit', label: 'Esci' }
      ]
    },
    {
      label: 'Visualizza',
      submenu: [
        { role: 'reload', label: 'Ricarica' },
        { role: 'toggleDevTools', label: 'Strumenti sviluppatore' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Schermo intero' }
      ]
    },
    {
      label: 'Fonti',
      submenu: [
        { label: 'IdroGEO ISPRA', click: () => shell.openExternal('https://idrogeo.isprambiente.it/app/') },
        { label: 'GeoPortale Regione Piemonte', click: () => shell.openExternal('https://www.geoportale.piemonte.it/visregpigo/') },
        { label: 'PAI AdBPo', click: () => shell.openExternal('https://pai.adbpo.it/') },
        { label: 'ARPA Piemonte — Geologia', click: () => shell.openExternal('https://www.arpa.piemonte.it/temi/geologia-dissesto') },
        { label: 'CARG 1:50.000 ISPRA', click: () => shell.openExternal('https://www.isprambiente.gov.it/it/progetti/suolo-e-territorio-1/la-carta-geologica-ditalia-alla-scala-1-a-50-000') },
      ]
    },
    {
      label: 'Aiuto',
      submenu: [
        {
          label: 'Guida uso',
          click: () => {
            const guidaPath = path.join(__dirname, '..', 'guide', 'GUIDA_USO.txt');
            shell.openPath(guidaPath);
          }
        },
        { label: 'README', click: () => shell.openPath(path.join(__dirname, '..', 'README.md')) },
        { type: 'separator' },
        { label: 'Anthropic Console (API keys)', click: () => shell.openExternal('https://console.anthropic.com/') },
        { label: 'Segnala problema', click: () => shell.openExternal('mailto:') }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  // Apri link esterni nel browser di sistema
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http') && !url.startsWith(`http://localhost:${PORT}`)) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

// ─── Lifecycle Electron ────────────────────────────────────────────────────
app.whenReady().then(async () => {
  createWindow();

  try {
    await startServer();
    await waitForServer();
    mainWindow.loadURL(`http://localhost:${PORT}`);
  } catch (err) {
    console.error('Errore avvio server:', err);
    // Fallback: carica index.html direttamente (senza AI)
    mainWindow.loadFile(path.join(__dirname, '..', 'index.html'));
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

// ─── IPC: gestione API key da interfaccia ─────────────────────────────────
ipcMain.handle('set-api-key', (event, apiKey) => {
  process.env.ANTHROPIC_API_KEY = apiKey;
  if (serverProcess) {
    // Riavvia il server con la nuova API key
    serverProcess.kill();
    setTimeout(startServer, 500);
  }
  return { success: true };
});

ipcMain.handle('get-api-key-status', () => {
  return { configured: !!process.env.ANTHROPIC_API_KEY };
});
