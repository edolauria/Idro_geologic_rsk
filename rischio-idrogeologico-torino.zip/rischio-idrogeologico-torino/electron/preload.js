/**
 * Electron Preload Script
 * Espone API sicure al renderer (context isolation)
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  setApiKey: (key) => ipcRenderer.invoke('set-api-key', key),
  getApiKeyStatus: () => ipcRenderer.invoke('get-api-key-status'),
  isElectron: true
});
