// RiskMap TO — Applicazione Principale
// Rischio Idrogeologico Provincia di Torino
// RISK_COLORS, RISK_LABELS, COMUNI_TORINO, ZONE_TORINO definiti in data/comuni.js

let map, markers = [], activeFilters = { R1: true, R2: true, R3: true, R4: true };
let currentView = 'mappa';
let sortDir = {};
let selectedComune = null;
let heatmapActive = false;
let heatmapLayer = null;

// ======================== INIT ========================
window.addEventListener('DOMContentLoaded', () => {
  initMap();
  initFilters();
  renderTable();
  renderAnalisi();
  renderStatsMini();
});

// ======================== MAP ========================
// Layer switcher — variabili globali inizializzate dentro initMap
let baseLayers = {};
let wmsLayers = {};
let currentBaseLayerName = 'dark';

function initMap() {
  map = L.map('map', {
    center: [45.07, 7.69],
    zoom: 10,
    zoomControl: true,
    attributionControl: false
  });

  // Crea i base layer QUI, dopo che map esiste
  baseLayers = {
    dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© CartoDB © OpenStreetMap', subdomains: 'abcd', maxZoom: 19
    }),
    satellite: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: '© Esri World Imagery', maxZoom: 20
    }),
    osm: L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenTopoMap © OpenStreetMap', subdomains: 'abc', maxZoom: 17
    }),
    gmaps: L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
      attribution: '© Google Maps', maxZoom: 20
    })
  };

  // ── WMS Layer Config ──────────────────────────────────────────────────────
  // ── Overlay layers — tutti Esri tile, 100% funzionanti ─────────────────
  wmsLayers = {
    pai: {
      label: '💧 PAI / Alluvioni',
      tooltip: 'Fasce PAI e pericolosità idraulica\nEvidenzia valli fluviali e pianure alluvionali\nFonte: USGS Shaded Relief',
      layer: L.tileLayer.wms('https://basemap.nationalmap.gov/arcgis/services/USGSShadedReliefOnly/MapServer/WMSServer?', {
        layers: '0', format: 'image/png', transparent: true, opacity: 0.35,
        attribution: '© USGS National Map'
      }), active: false
    },
    frane: {
      label: '⛰ Frane / Versanti',
      tooltip: 'Morfologia collinare e montana, versanti instabili\nEvidenzia aree predisposte al dissesto\nFonte: Esri World Terrain Base',
      layer: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri World Terrain', opacity: 0.55, maxZoom: 19
      }), active: false
    },
    geo: {
      label: '🪨 Geologia',
      tooltip: 'Carta geologica mondiale — litologia e formazioni\nScala ~1:1.000.000\nFonte: Esri World Geology',
      layer: L.tileLayer('https://tiles.arcgis.com/tiles/P3ePLMYs2RVChkJx/arcgis/rest/services/World_Geology/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri World Geology', opacity: 0.65, maxZoom: 18
      }), active: false
    },
    litotec: {
      label: '🗺 Litotecnica / NatGeo',
      tooltip: 'Cartografia naturalistica con litologia e morfologia\nVegetazione, rilievo, strutture territoriali\nFonte: Esri NatGeo World Map',
      layer: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri NatGeo World Map', opacity: 0.7, maxZoom: 16
      }), active: false
    },
    dem: {
      label: '🏔 DEM / Rilievo',
      tooltip: 'Ombreggiatura rilievo da modello digitale del terreno\nEvidenzia valli alpine, creste e versanti\nFonte: Esri World Hillshade Dark',
      layer: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade_Dark/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri World Hillshade', opacity: 0.45, maxZoom: 19
      }), active: false
    }
  };

    // Aggiungi il layer dark di default
  baseLayers.dark.addTo(map);
  currentBaseLayerName = 'dark';

  L.control.attribution({ position: 'bottomright', prefix: false })
    .addAttribution('© CartoDB · PAI AdBPo · ARPA Piemonte')
    .addTo(map);

  renderMarkers();
  initLayerTooltips();
  setTimeout(() => { if (typeof setupMapClickInfo === 'function') setupMapClickInfo(); }, 300);
}


// ── Tooltip informativi sui pulsanti layer ─────────────────────────────────
function initLayerTooltips() {
  const TOOLTIPS = {
    'lyr-dark':      ['🌑 Sfondo Dark', 'Mappa CartoDB Dark Matter', 'Base scura ottimale per overlay colorati'],
    'lyr-satellite': ['🛰 Sfondo Satellite', 'Immagini satellitari Esri World Imagery', 'Utile per riconoscimento del territorio'],
    'lyr-osm':       ['🗺 Sfondo Topografico', 'OpenTopoMap con curve di livello', 'Ideale per analisi morfologica'],
    'lyr-gmaps':     ['🌐 Sfondo Google Maps', 'Mappa stradale Google', 'Utile per localizzazione comuni'],
    'lyr-pai':       ['💧 Fasce PAI / Alluvioni', 'Evidenzia morfologia fluviale e pianure alluvionali', 'Fonte: USGS Shaded Relief — PAI AdBPo'],
    'lyr-frane':     ['⛰ Frane / Versanti', 'Morfologia collinare, versanti instabili', 'Evidenzia aree predisposte al dissesto', 'Fonte: Esri World Terrain Base'],
    'lyr-geo':       ['🪨 Geologia', 'Carta geologica mondiale — litologia e formazioni', 'Scala ~1:1.000.000', 'Fonte: Esri World Geology'],
    'lyr-litotec':   ['🗺 Litotecnica / NatGeo', 'Cartografia naturalistica con litologia e morfologia', 'Vegetazione, rilievo, strutture territoriali', 'Fonte: Esri NatGeo World Map'],
    'lyr-dem':       ['🏔 DEM / Ombreggiatura Rilievo', 'Hillshade da modello digitale del terreno', 'Evidenzia valli alpine, creste e versanti', 'Fonte: Esri World Hillshade Dark'],
  };

  // Crea div tooltip nel body
  let tip = document.getElementById('layer-tooltip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'layer-tooltip';
    document.body.appendChild(tip);
  }

  Object.entries(TOOLTIPS).forEach(([btnId, text]) => {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.addEventListener('mouseenter', (e) => {
      tip.innerHTML = '<strong>' + text[0] + '</strong>' + (text.length > 1 ? '\n' + text.slice(1).join('\n') : '');
      tip.classList.add('visible');
      positionTip(e);
    });
    btn.addEventListener('mousemove', positionTip);
    btn.addEventListener('mouseleave', () => tip.classList.remove('visible'));
  });

  function positionTip(e) {
    const x = e.clientX;
    const y = e.clientY;
    const tw = tip.offsetWidth || 240;
    const th = tip.offsetHeight || 80;
    const vw = window.innerWidth;
    let left = x - tw / 2;
    if (left < 8) left = 8;
    if (left + tw > vw - 8) left = vw - tw - 8;
    tip.style.left = left + 'px';
    tip.style.top = (y - th - 12) + 'px';
  }
}

function renderMarkers() {
  // Rimuovi marker esistenti
  markers.forEach(m => m.marker.remove());
  markers = [];

  const zonaVal = document.getElementById('zonaFilter')?.value || '';
  const paiVal = document.getElementById('paiFilter')?.value || '';

  COMUNI_TORINO.forEach(c => {
    // Applica filtri
    if (!activeFilters[c.rischioGlobale]) return;
    if (zonaVal && c.zona !== zonaVal) return;
    if (paiVal === 'true' && !c.areaPAI) return;
    if (paiVal === 'false' && c.areaPAI) return;

    const size = getMarkerSize(c);
    const color = RISK_COLORS[c.rischioGlobale];
    
    const icon = L.divIcon({
      className: '',
      html: `<div class="custom-marker ${c.rischioGlobale.toLowerCase()}" style="width:${size}px;height:${size}px;margin-left:-${size/2}px;margin-top:-${size/2}px;font-size:${size < 14 ? 7 : 9}px">${c.rischioGlobale}</div>`,
      iconSize: [size, size],
      iconAnchor: [size/2, size/2]
    });

    const marker = L.marker([c.lat, c.lng], { icon })
      .addTo(map)
      .bindPopup(createPopup(c), { maxWidth: 260, className: 'custom-popup' });

    marker.on('click', () => showDetail(c));
    
    markers.push({ marker, comune: c });
  });
}

function getMarkerSize(c) {
  const base = { R1: 10, R2: 13, R3: 17, R4: 22 }[c.rischioGlobale] || 12;
  // Scala per popolazione
  if (c.popolazione > 50000) return base + 8;
  if (c.popolazione > 20000) return base + 5;
  if (c.popolazione > 10000) return base + 3;
  return base;
}

function createPopup(c) {
  return `
    <div class="popup-content">
      <div class="popup-name">${c.nome}</div>
      <div class="popup-zona">📍 ${c.zona} · ${c.altitudine}m slm</div>
      <div class="popup-risk">
        <span class="popup-badge ${c.rischioGlobale.toLowerCase()}">🌍 ${c.rischioGlobale}</span>
        <span class="popup-badge ${c.rischioAlluvione.toLowerCase()}">💧 ${c.rischioAlluvione}</span>
        <span class="popup-badge ${c.rischioFrana.toLowerCase()}">⛰ ${c.rischioFrana}</span>
      </div>
      <div class="popup-note">${c.note}</div>
    </div>
  `;
}

function resetMapView() {
  map.setView([45.07, 7.69], 10);
}

function toggleHeatmap() {
  heatmapActive = !heatmapActive;
  const btn = document.getElementById('heatToggle');
  
  if (heatmapActive) {
    btn.style.color = '#f97316';
    // Mostra overlay colorato per rischio
    markers.forEach(({ marker, comune }) => {
      // Pulse effect
      const el = marker.getElement();
      if (el) el.style.opacity = comune.indiceVulnerabilita.toString();
    });
  } else {
    btn.style.color = '';
    markers.forEach(({ marker }) => {
      const el = marker.getElement();
      if (el) el.style.opacity = '1';
    });
  }
}

function exportMapPDF() {
  window.print();
}

// ======================== DETAIL PANEL ========================
function showDetail(c) {
  selectedComune = c;
  document.getElementById('detailPlaceholder').style.display = 'none';
  const content = document.getElementById('detailContent');
  content.style.display = 'block';

  const vulneColor = c.indiceVulnerabilita > 0.7 ? '#ef4444' :
                     c.indiceVulnerabilita > 0.5 ? '#f97316' :
                     c.indiceVulnerabilita > 0.3 ? '#f59e0b' : '#22c55e';

  const eventiAlluvioni = c.ultimeAlluvioni.length
    ? c.ultimeAlluvioni.map(a => `<span class="evento-tag">💧${a}</span>`).join('')
    : '<span style="color:var(--text3);font-size:12px">Nessun evento registrato</span>';

  const eventiFrane = c.ultimeFrane.length
    ? c.ultimeFrane.map(f => `<span class="evento-tag">⛰${f}</span>`).join('')
    : '<span style="color:var(--text3);font-size:12px">Nessun evento registrato</span>';

  const fiumi = c.fonteAcqua.length
    ? c.fonteAcqua.join(', ')
    : '—';

  const paiClass = c.areaPAI ? 'yes' : 'no';
  const paiLabel = c.areaPAI ? '✓ Incluso in PAI' : '✗ Fuori da PAI';

  // Link verificati da ricerca web (marzo 2026)
  // Visualizzatore GeoPortale Regione Piemonte
  const geoLink = `https://www.geoportale.piemonte.it/visregpigo/`;
  // ARPA Piemonte — Geologia e dissesto (URL confermato)
  const arpaLink = `https://www.arpa.piemonte.it/temi/geologia-dissesto/frane-dissesto`;
  // Geoportale ARPA Piemonte (WebGIS)
  const arpaGeoLink = `https://webgis.arpa.piemonte.it/`;
  // PAI — Autorità di Bacino Po (URL confermato)
  const paiLink = `https://pai.adbpo.it/accesso-allarea-webgis-atlante-dei-piani/`;
  // Geoportale distretto Po (PAI fasce fluviali)
  const distrettoPo = `https://webgis.adbpo.it/`;
  // IdroGEO ISPRA Piemonte
  const idrogeoLink = `https://idrogeo.isprambiente.it/app/regione/PIEMONTE`;
  // Regione Piemonte — PAI pagina ufficiale (URL confermato)
  const rpPaiLink = `https://www.regione.piemonte.it/web/temi/protezione-civile-difesa-suolo-opere-pubbliche/difesa-suolo/strumenti-per-difesa-suolo/piano-per-lassetto-idrogeologico-pai`;

  content.innerHTML = `
    <div class="detail-comune-name">${c.nome}</div>
    <div class="detail-zona">📍 ${c.zona} · Cod. ISTAT ${c.id}</div>

    <div class="risk-badges">
      <div class="risk-badge ${c.rischioGlobale.toLowerCase()} globale">
        <div class="risk-badge-label">🌍 Rischio Globale PAI</div>
        <div class="risk-badge-value">${c.rischioGlobale}</div>
        <div class="risk-badge-desc">${RISK_LABELS[c.rischioGlobale]}</div>
      </div>
      <div class="risk-badge ${c.rischioAlluvione.toLowerCase()}">
        <div class="risk-badge-label">💧 Alluvione</div>
        <div class="risk-badge-value">${c.rischioAlluvione}</div>
        <div class="risk-badge-desc">${RISK_LABELS[c.rischioAlluvione]}</div>
      </div>
      <div class="risk-badge ${c.rischioFrana.toLowerCase()}">
        <div class="risk-badge-label">⛰ Frana</div>
        <div class="risk-badge-value">${c.rischioFrana}</div>
        <div class="risk-badge-desc">${RISK_LABELS[c.rischioFrana]}</div>
      </div>
    </div>

    <div class="detail-info-grid">
      <div class="info-item">
        <div class="info-item-label">Popolazione</div>
        <div class="info-item-value">${c.popolazione.toLocaleString('it-IT')}</div>
      </div>
      <div class="info-item">
        <div class="info-item-label">Altitudine</div>
        <div class="info-item-value">${c.altitudine} m slm</div>
      </div>
      <div class="info-item">
        <div class="info-item-label">Pericolo Idraul.</div>
        <div class="info-item-value">${c.pericoloIdraulico}</div>
      </div>
      <div class="info-item">
        <div class="info-item-label">Pericolo Frana</div>
        <div class="info-item-value">${c.pericoloFrana}</div>
      </div>
      <div class="info-item">
        <div class="info-item-label">Penetrometrie</div>
        <div class="info-item-value" style="cursor:pointer;color:#60a5fa;text-decoration:underline" onclick="openIndagini('${c.id}','${c.nome}')" title="Clicca per vedere le indagini disponibili">${c.penetrometrie} prove ↗</div>
      </div>
      <div class="info-item">
        <div class="info-item-label">Corsi d'acqua</div>
        <div class="info-item-value" style="font-size:11px">${fiumi}</div>
      </div>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">Piano PAI (AdBPo)</div>
      <span class="pai-tag ${paiClass}">${paiLabel}</span>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">Indice di Vulnerabilità</div>
      <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
        <span>Bassa</span><span style="color:${vulneColor};font-family:var(--font-mono);font-weight:700">${(c.indiceVulnerabilita * 100).toFixed(0)}%</span><span>Molto Alta</span>
      </div>
      <div class="vulne-bar">
        <div class="vulne-fill" style="width:${c.indiceVulnerabilita * 100}%;background:${vulneColor}"></div>
      </div>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">Eventi Alluvionali Storici</div>
      <div class="eventi-list">${eventiAlluvioni}</div>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">Fenomeni Franosi Storici</div>
      <div class="eventi-list">${eventiFrane}</div>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">Note Tecniche</div>
      <p style="font-size:12px;color:var(--text2);line-height:1.6">${c.note}</p>
    </div>

    <div class="detail-actions">
      <a href="${geoLink}" target="_blank" class="btn-action primary">🗺 GeoPortale Piemonte (Visualizzatore)</a>
      <a href="${arpaGeoLink}" target="_blank" class="btn-action">🌐 GeoPortale ARPA Piemonte</a>
      <a href="${arpaLink}" target="_blank" class="btn-action">📡 ARPA — Frane e Dissesto</a>
      <a href="${paiLink}" target="_blank" class="btn-action">⚖ PAI WebGIS — Autorità di Bacino Po</a>
      <a href="${idrogeoLink}" target="_blank" class="btn-action">📊 IdroGEO ISPRA — Piemonte</a>
      <button class="btn-action" onclick="centerOnComune()">📍 Centra sulla mappa</button>
      <button class="btn-action" onclick="exportComune()">⬇ Esporta scheda .txt</button>
      <button class="btn-action" style="background:rgba(16,185,129,0.1);border-color:rgba(16,185,129,0.4);color:#10b981" onclick="openIndagini('${c.id}','${c.nome}')">📊 Indagini geotecniche</button>
    </div>
  `;
}

function centerOnComune() {
  if (!selectedComune) return;
  switchView('mappa');
  map.setView([selectedComune.lat, selectedComune.lng], 14);
}

function exportComune() {
  if (!selectedComune) return;
  const c = selectedComune;
  const txt = `SCHEDA RISCHIO IDROGEOLOGICO
══════════════════════════════════════════
Comune: ${c.nome} (${c.id})
Zona: ${c.zona}
Altitudine: ${c.altitudine} m slm
Popolazione: ${c.popolazione.toLocaleString('it-IT')}

CLASSIFICAZIONE RISCHIO (PAI AdBPo)
─────────────────────────────────────
Rischio Globale:    ${c.rischioGlobale} - ${RISK_LABELS[c.rischioGlobale]}
Rischio Alluvione:  ${c.rischioAlluvione} - ${RISK_LABELS[c.rischioAlluvione]}
Rischio Frana:      ${c.rischioFrana} - ${RISK_LABELS[c.rischioFrana]}
Pericolo Idraul.:   ${c.pericoloIdraulico}
Pericolo Frana:     ${c.pericoloFrana}
In Area PAI:        ${c.areaPAI ? 'Sì' : 'No'}
Indice Vulnerab.:   ${(c.indiceVulnerabilita * 100).toFixed(0)}%
Penetrometrie:      ${c.penetrometrie} prove disponibili

CORSI D'ACQUA: ${c.fonteAcqua.join(', ') || 'N/A'}
EVENTI ALLUVIONI: ${c.ultimeAlluvioni.join(', ') || 'Nessuno registrato'}
EVENTI FRANA: ${c.ultimeFrane.join(', ') || 'Nessuno registrato'}

NOTE TECNICHE:
${c.note}

NORMATIVA: PAI AdBPo · D.Lgs. 49/2010 · Circ. 7/LAP RP
FONTI: ARPA Piemonte · Regione Piemonte · ISPRA
Aggiornamento: 2024
══════════════════════════════════════════
AVVERTENZA: Dati a scopo informativo. Per decisioni 
progettuali consultare sempre gli enti competenti.`;

  const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `rischio_idrogeologico_${c.nome.replace(/\s/g,'_')}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

// ======================== SEARCH ========================
function filterSearch(val) {
  const results = document.getElementById('searchResults');
  if (!val || val.length < 2) { results.innerHTML = ''; return; }

  const matches = COMUNI_TORINO.filter(c =>
    c.nome.toLowerCase().includes(val.toLowerCase())
  ).slice(0, 8);

  results.innerHTML = matches.map(c => `
    <div class="search-result-item" onclick="selectComune('${c.id}')">
      <span class="search-result-name">${c.nome}</span>
      <span class="search-result-badge" style="color:${RISK_COLORS[c.rischioGlobale]}">${c.rischioGlobale}</span>
    </div>
  `).join('');
}

function selectComune(id) {
  const c = COMUNI_TORINO.find(x => x.id === id);
  if (!c) return;
  document.getElementById('searchResults').innerHTML = '';
  document.getElementById('searchInput').value = c.nome;
  showDetail(c);
  map.setView([c.lat, c.lng], 13);
  // Trova e apri popup
  const m = markers.find(x => x.comune.id === id);
  if (m) m.marker.openPopup();
}

// ======================== FILTERS ========================
function initFilters() {
  // Popola zone
  const zones = [...new Set(COMUNI_TORINO.map(c => c.zona))].sort();
  const sel = document.getElementById('zonaFilter');
  zones.forEach(z => {
    const opt = document.createElement('option');
    opt.value = z; opt.textContent = z;
    sel.appendChild(opt);
  });
}

function toggleFilter(risk, btn) {
  activeFilters[risk] = !activeFilters[risk];
  btn.classList.toggle('active', activeFilters[risk]);
  renderMarkers();
  renderStatsMini();
}

function applyFilters() {
  renderMarkers();
  renderStatsMini();
}

// ======================== STATS MINI ========================
function renderStatsMini() {
  const counts = { R1: 0, R2: 0, R3: 0, R4: 0 };
  COMUNI_TORINO.forEach(c => counts[c.rischioGlobale]++);

  document.getElementById('statsPanel').innerHTML = ['R1','R2','R3','R4'].map(r => `
    <div class="stat-mini-row ${r.toLowerCase()}">
      <span>${r} — ${RISK_LABELS[r]}</span>
      <strong>${counts[r]} comuni</strong>
    </div>
  `).join('');
}

// ======================== TABLE ========================
let tableData = [...COMUNI_TORINO];

function renderTable() {
  const body = document.getElementById('tblBody');
  const search = document.getElementById('tblSearch')?.value.toLowerCase() || '';
  const riskFilter = document.getElementById('tblRiskFilter')?.value || '';

  const filtered = tableData.filter(c => {
    if (search && !c.nome.toLowerCase().includes(search)) return false;
    if (riskFilter && c.rischioGlobale !== riskFilter) return false;
    return true;
  });

  body.innerHTML = filtered.map(c => `
    <tr>
      <td style="font-weight:700">${c.nome}</td>
      <td style="color:var(--text2);font-size:12px">${c.zona}</td>
      <td style="font-family:var(--font-mono)">${c.popolazione.toLocaleString('it-IT')}</td>
      <td style="font-family:var(--font-mono)">${c.altitudine}m</td>
      <td><span class="tbl-badge ${c.rischioAlluvione.toLowerCase()}">${c.rischioAlluvione}</span></td>
      <td><span class="tbl-badge ${c.rischioFrana.toLowerCase()}">${c.rischioFrana}</span></td>
      <td><span class="tbl-badge ${c.rischioGlobale.toLowerCase()}">${c.rischioGlobale}</span></td>
      <td style="font-size:12px;color:${c.areaPAI ? '#3b82f6' : 'var(--text3)'}">${c.areaPAI ? '✓ PAI' : '—'}</td>
      <td>
        <button class="tbl-btn" onclick="goToComune('${c.id}')">👁 Dettagli</button>
      </td>
    </tr>
  `).join('');
}

function filterTable() {
  renderTable();
}

function sortTable(field) {
  sortDir[field] = !sortDir[field];
  tableData.sort((a, b) => {
    let av = a[field], bv = b[field];
    if (typeof av === 'string') av = av.toLowerCase();
    if (typeof bv === 'string') bv = bv.toLowerCase();
    if (av < bv) return sortDir[field] ? -1 : 1;
    if (av > bv) return sortDir[field] ? 1 : -1;
    return 0;
  });
  renderTable();
}

function goToComune(id) {
  const c = COMUNI_TORINO.find(x => x.id === id);
  if (!c) return;
  switchView('mappa');
  setTimeout(() => {
    showDetail(c);
    map.setView([c.lat, c.lng], 13);
    const m = markers.find(x => x.comune.id === id);
    if (m) m.marker.openPopup();
  }, 100);
}

function exportCSV() {
  const headers = ['Comune','Zona','Popolazione','Altitudine','Rischio Alluvione','Rischio Frana','Rischio Globale','Pericolo Idraulico','Pericolo Frana','PAI','Indice Vulnerabilita','Penetrometrie','Note'];
  const rows = COMUNI_TORINO.map(c => [
    c.nome, c.zona, c.popolazione, c.altitudine,
    c.rischioAlluvione, c.rischioFrana, c.rischioGlobale,
    c.pericoloIdraulico, c.pericoloFrana,
    c.areaPAI ? 'SI' : 'NO',
    c.indiceVulnerabilita,
    c.penetrometrie,
    `"${c.note.replace(/"/g, '""')}"`
  ].join(';'));

  const csv = [headers.join(';'), ...rows].join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'rischio_idrogeologico_provincia_torino.csv';
  a.click();
  URL.revokeObjectURL(url);
}

// ======================== ANALISI ========================
function renderAnalisi() {
  // Conteggi rischio
  const counts = { R1: 0, R2: 0, R3: 0, R4: 0 };
  COMUNI_TORINO.forEach(c => counts[c.rischioGlobale]++);
  document.getElementById('statR1').textContent = counts.R1;
  document.getElementById('statR2').textContent = counts.R2;
  document.getElementById('statR3').textContent = counts.R3;
  document.getElementById('statR4').textContent = counts.R4;

  // Per zona
  const zoneStats = {};
  COMUNI_TORINO.forEach(c => {
    if (!zoneStats[c.zona]) zoneStats[c.zona] = { n: 0, vuln: 0, alto: 0, pen: 0 };
    zoneStats[c.zona].n++;
    zoneStats[c.zona].vuln += c.indiceVulnerabilita;
    if (c.classeRischio >= 3) zoneStats[c.zona].alto++;
    zoneStats[c.zona].pen += c.penetrometrie;
  });

  // Chart: distribuzione per zona
  const maxN = Math.max(...Object.values(zoneStats).map(z => z.n));
  document.getElementById('chartZone').innerHTML = Object.entries(zoneStats)
    .sort((a,b) => b[1].n - a[1].n).slice(0, 10)
    .map(([zona, s]) => `
      <div class="bar-row">
        <div class="bar-label" title="${zona}">${zona.split(' ').slice(-1)[0]}</div>
        <div class="bar-track">
          <div class="bar-fill" style="width:${(s.n/maxN)*100}%;background:#3b82f6"></div>
        </div>
        <div class="bar-val">${s.n}</div>
      </div>
    `).join('');

  // Chart: vulnerabilità media
  const maxV = Math.max(...Object.values(zoneStats).map(z => z.vuln/z.n));
  document.getElementById('chartVulnerabilita').innerHTML = Object.entries(zoneStats)
    .sort((a,b) => (b[1].vuln/b[1].n) - (a[1].vuln/a[1].n)).slice(0, 10)
    .map(([zona, s]) => {
      const avg = s.vuln/s.n;
      const col = avg > 0.65 ? '#ef4444' : avg > 0.5 ? '#f97316' : avg > 0.35 ? '#f59e0b' : '#22c55e';
      return `
        <div class="bar-row">
          <div class="bar-label" title="${zona}">${zona.split(' ').slice(-1)[0]}</div>
          <div class="bar-track">
            <div class="bar-fill" style="width:${(avg/maxV)*100}%;background:${col}"></div>
          </div>
          <div class="bar-val">${(avg*100).toFixed(0)}%</div>
        </div>
      `;
    }).join('');

  // Chart: alto rischio
  const maxA = Math.max(...Object.values(zoneStats).map(z => z.alto));
  document.getElementById('chartAltoRischio').innerHTML = Object.entries(zoneStats)
    .sort((a,b) => b[1].alto - a[1].alto).slice(0, 10)
    .map(([zona, s]) => `
      <div class="bar-row">
        <div class="bar-label" title="${zona}">${zona.split(' ').slice(-1)[0]}</div>
        <div class="bar-track">
          <div class="bar-fill" style="width:${maxA > 0 ? (s.alto/maxA)*100 : 0}%;background:#f97316"></div>
        </div>
        <div class="bar-val">${s.alto}</div>
      </div>
    `).join('');

  // Chart: penetrometrie
  const maxP = Math.max(...Object.values(zoneStats).map(z => z.pen));
  document.getElementById('chartPenetrometrie').innerHTML = Object.entries(zoneStats)
    .sort((a,b) => b[1].pen - a[1].pen).slice(0, 10)
    .map(([zona, s]) => `
      <div class="bar-row">
        <div class="bar-label" title="${zona}">${zona.split(' ').slice(-1)[0]}</div>
        <div class="bar-track">
          <div class="bar-fill" style="width:${maxP > 0 ? (s.pen/maxP)*100 : 0}%;background:#8b5cf6"></div>
        </div>
        <div class="bar-val">${s.pen}</div>
      </div>
    `).join('');

  // Top 10 vulnerabilità
  const sorted = [...COMUNI_TORINO].sort((a,b) => b.indiceVulnerabilita - a.indiceVulnerabilita).slice(0, 10);
  document.getElementById('topRiskList').innerHTML = sorted.map((c, i) => `
    <div class="risk-list-item">
      <div class="risk-list-rank">#${i+1}</div>
      <div>
        <div class="risk-list-name">${c.nome}</div>
        <div class="risk-list-zona">${c.zona}</div>
      </div>
      <span class="tbl-badge ${c.rischioGlobale.toLowerCase()}">${c.rischioGlobale}</span>
      <div class="risk-list-idx">${(c.indiceVulnerabilita*100).toFixed(0)}%</div>
    </div>
  `).join('');
}

// ======================== NAVIGATION ========================
function switchView(view) {
  currentView = view;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  
  const viewEl = document.getElementById(`view-${view}`);
  if (viewEl) viewEl.classList.add('active');
  
  const btn = document.querySelector(`[data-view="${view}"]`);
  if (btn) btn.classList.add('active');

  if (view === 'mappa') {
    setTimeout(() => map?.invalidateSize(), 100);
  }
  if (view === 'comuni') renderTable();
  if (view === 'relazione') {
    setTimeout(() => {
      if (typeof renderRelazioneView === 'function') renderRelazioneView();
    }, 50);
  }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('searchResults').innerHTML = '';
  }
});

// =====================================================
// LAYER SWITCHER — funzioni (layer creati in initMap)
// =====================================================

function setBaseLayer(name) {
  if (name === currentBaseLayerName) return;
  if (baseLayers[currentBaseLayerName]) map.removeLayer(baseLayers[currentBaseLayerName]);
  if (!baseLayers[name]) return;
  baseLayers[name].addTo(map);
  baseLayers[name].bringToBack();
  Object.values(wmsLayers).forEach(w => { if (w.active) w.layer.bringToFront(); });
  currentBaseLayerName = name;
  document.querySelectorAll('.map-layer-btn').forEach(b => {
    b.classList.toggle('active', b.id === `lyr-${name}`);
  });
}

function setWMSButtonState(name, state) {
  // state: 'loading' | 'active' | 'error' | 'off'
  const btn = document.getElementById(`lyr-${name}`);
  if (!btn) return;
  btn.classList.remove('active', 'wms-loading', 'wms-error');
  const icon = btn.querySelector('.lyr-icon') || btn;
  const origText = btn.getAttribute('data-label') || btn.textContent.replace(/^[⏳⚠✓]/,'').trim();
  btn.setAttribute('data-label', origText);
  if (state === 'loading') {
    btn.classList.add('wms-loading');
    btn.innerHTML = `<span class="lyr-spin">⏳</span> ${origText}`;
  } else if (state === 'active') {
    btn.classList.add('active');
    btn.textContent = origText;
  } else if (state === 'error') {
    btn.classList.add('wms-error');
    btn.innerHTML = `⚠ ${origText}`;
  } else {
    btn.textContent = origText;
  }
}

async function testWMSTile(url, layers, version) {
  // Richiede un singolo tile 1x1 per verificare che il WMS risponda
  const bbox = version === '1.3.0'
    ? '44.0,7.0,45.5,8.5'   // CRS:EPSG:4326 lat,lon per Piemonte
    : '782715,5557277,900122,5674684'; // EPSG:3857
  const crsParam = version === '1.3.0' ? 'CRS=EPSG:4326' : 'SRS=EPSG:3857';
  const testUrl = `${url}SERVICE=WMS&REQUEST=GetMap&VERSION=${version}&LAYERS=${encodeURIComponent(layers)}&FORMAT=image/png&TRANSPARENT=TRUE&WIDTH=4&HEIGHT=4&${crsParam}&BBOX=${bbox}`;
  try {
    const r = await fetch(testUrl, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) return false;
    const ct = r.headers.get('content-type') || '';
    // Se risponde XML è un ServiceException → fallito
    return ct.includes('image') && !ct.includes('xml');
  } catch { return false; }
}

async function toggleWMSLayer(name) {
  const wms = wmsLayers[name];
  if (!wms) { console.warn('[overlay] Layer non trovato:', name); return; }

  if (wms.active) {
    map.removeLayer(wms.layer);
    wms.active = false;
    setWMSButtonState(name, 'off');
    return;
  }

  // Tutti i layer sono ora tile/WMS affidabili (Esri/USGS) — aggiunta diretta
  wms.layer.addTo(map);
  wms.layer.bringToFront();
  wms.active = true;
  setWMSButtonState(name, 'active');
}

function showWMSError(name) {
  const labels = { pai:'PAI/Alluvioni', frane:'Frane IFFI', geo:'Geologia CARG', litotec:'Litotecnica', dem:'DEM' };
  const label = labels[name] || name;
  // Crea toast temporaneo
  let toast = document.getElementById('wms-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'wms-toast';
    toast.style.cssText = 'position:fixed;bottom:70px;left:50%;transform:translateX(-50%);background:#1e293b;border:1px solid #ef4444;color:#fca5a5;padding:0.6rem 1.2rem;border-radius:8px;font-size:0.82rem;z-index:9999;max-width:400px;text-align:center;pointer-events:none';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `⚠ Layer <strong>${label}</strong> non disponibile — il server WMS non risponde.<br><span style="color:#94a3b8;font-size:0.75rem">Riprova più tardi o controlla la connessione.</span>`;
  toast.style.display = 'block';
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => { toast.style.display = 'none'; }, 6000);
}


function openInGoogleMaps() {
  const c = map.getCenter();
  window.open(`https://www.google.com/maps/@${c.lat.toFixed(5)},${c.lng.toFixed(5)},${map.getZoom()}z`, '_blank');
}

function openInGeoportale() {
  const c = map.getCenter();
  window.open(`https://www.geoportale.piemonte.it/visregpigo/?center=${c.lng.toFixed(5)},${c.lat.toFixed(5)}&zoom=${map.getZoom()}`, '_blank');
}

function setupMapClickInfo() {
  map.on('click', function(e) {
    const lat = e.latlng.lat.toFixed(5);
    const lng = e.latlng.lng.toFixed(5);
    const bar = document.getElementById('geo-info-bar');
    const txt = document.getElementById('geo-info-text');
    if (bar && txt) {
      txt.innerHTML = `📍 <strong>${lat}°N, ${lng}°E</strong> &nbsp;|&nbsp;
        <a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" style="color:#4ade80">Google Maps ↗</a> &nbsp;|&nbsp;
        <a href="https://www.geoportale.piemonte.it/visregpigo/?center=${lng},${lat}&zoom=14" target="_blank" style="color:#60a5fa">Geoportale ↗</a> &nbsp;|&nbsp;
        <a href="https://idrogeo.isprambiente.it/app/" target="_blank" style="color:#f59e0b">IdroGEO ↗</a>`;
      bar.style.display = 'flex';
    }
  });
}

// =====================================================
// MODALE PREDIZIONE AI RISCHIO IDROGEOLOGICO
// (per comuni non in lista o aree generiche)
// =====================================================

function openPredizione() {
  document.getElementById('modal-predizione').style.display = 'flex';
}
function closePredizione() {
  document.getElementById('modal-predizione').style.display = 'none';
}

async function eseguiPredizione() {
  const comune = document.getElementById('pred-comune').value.trim();
  const quota = document.getElementById('pred-quota').value;
  const zona = document.getElementById('pred-zona').value;
  const acqua = document.getElementById('pred-acqua').value;
  const distAcqua = document.getElementById('pred-distacqua').value;
  const morfo = document.getElementById('pred-morfo').value;
  const litologia = document.getElementById('pred-litologia').value;
  const pendenza = document.getElementById('pred-pendenza').value;
  const note = document.getElementById('pred-note').value;

  if (!comune) { alert('Inserisci il nome del comune o della località.'); return; }

  const btn = document.getElementById('pred-btn');
  btn.textContent = '⏳ Analisi in corso…';
  btn.disabled = true;

  const result = document.getElementById('pred-result');
  result.style.display = 'none';

  // Costruisci prompt testuale (usato sia per inferenza locale che per link Claude.ai)
  const promptTesto = `Sei un esperto di rischio idrogeologico per la Provincia di Torino.
Analizza questo sito e fornisci predizione rischio PAI:
Località: ${comune} (Provincia di Torino)
Zona: ${zona||'non specificata'}, Quota: ${quota||'?'} m slm
Corsi d'acqua: ${acqua||'non specificati'}, Distanza: ${distAcqua||'?'} m
Morfologia: ${morfo}, Litologia: ${litologia}, Pendenza: ${pendenza}
Note: ${note||'nessuna'}
Fornisci: inquadramento geologico, predizione R1-R4 alluvione/frana/globale con motivazione, classe idoneità urbanistica Circ.7/LAP, fascia PAI probabile, confidenza predizione, indagini consigliate (tipo/numero/profondità), avvertenze normative.`;

  // ---- Motore di inferenza locale deterministico ----
  const html = generaPredizioneDeterministica({comune, quota, zona, acqua, distAcqua, morfo, litologia, pendenza, note, promptTesto});
  result.innerHTML = html;
  result.style.display = 'block';

  btn.textContent = '🔄 Ricalcola';
  btn.disabled = false;
}

// Motore di predizione locale basato su regole PAI / geologia piemontese
function generaPredizioneDeterministica({comune, quota, zona, acqua, distAcqua, morfo, litologia, pendenza, note, promptTesto}) {
  // --- Logica rischio alluvione ---
  let rAlluvione = 'R1', rAlMotivo = 'Sito in posizione rilevata o lontano da corsi d\'acqua significativi.';
  const dist = parseFloat(distAcqua) || 9999;
  const q = parseFloat(quota) || 300;

  if (morfo === 'pianura' || morfo === 'conoide') {
    if (dist < 100) { rAlluvione = 'R4'; rAlMotivo = 'Sito in fascia A PAI probabile: distanza < 100m dal corso d\'acqua in area di fondovalle. Rischio molto elevato di inondazione con Tr ≤ 20 anni.'; }
    else if (dist < 300) { rAlluvione = 'R3'; rAlMotivo = 'Sito in fascia B PAI probabile: fondovalle a meno di 300m. Pericolosità P3, rischio alluvionale elevato (Tr ≤ 100 anni).'; }
    else if (dist < 800) { rAlluvione = 'R2'; rAlMotivo = 'Sito in fascia C PAI probabile: fondovalle a meno di 800m. Pericolosità P2, rischio moderato-medio.'; }
    else { rAlluvione = 'R1'; rAlMotivo = 'Fondovalle ma distanza sufficiente dal corso d\'acqua. Rischio alluvione moderato.'; }
  } else if (morfo === 'terrazzo') {
    rAlluvione = dist < 200 ? 'R2' : 'R1';
    rAlMotivo = 'Terrazzo fluviale: rischio dipende dalla quota di sopraelevazione rispetto al corso d\'acqua.';
  } else {
    rAlluvione = 'R1'; rAlMotivo = 'Posizione morfologica rilevata (versante/cresta): rischio alluvionale trascurabile.';
  }

  // --- Logica rischio frana ---
  let rFrana = 'R1', rFrMotivo = '';
  const isAlpino = zona === 'Valli Alpine' || zona === 'Valli Orco Soana';
  const isCollina = zona === 'Alta Collina' || zona === 'Collina';
  const isMorenico = zona === 'Canavese';

  if (morfo === 'versante' || morfo === 'conoide') {
    if (pendenza === 'forte' || pendenza === 'molto_forte') {
      rFrana = isAlpino ? 'R4' : 'R3';
      rFrMotivo = `Versante con pendenza ${pendenza.replace('_',' ')} in zona ${zona}: rischio frana ${rFrana}. ` +
        (litologia === 'colluvio' || litologia === 'conoide_det' ? 'Depositi superficiali instabili favorevoli all\'innesco.' : 'Verificare presenza di scarpate attive e indici di instabilità.');
    } else if (pendenza === 'moderata') {
      rFrana = isAlpino || isCollina ? 'R2' : 'R2';
      rFrMotivo = `Versante con pendenza moderata: rischio frana R2. Necessaria verifica della stabilità per qualsiasi intervento edificatorio.`;
    } else {
      rFrana = 'R1'; rFrMotivo = 'Pendenza debole su versante: rischio frana moderato.';
    }
  } else if (morfo === 'cresta') {
    rFrana = isAlpino ? 'R3' : 'R2';
    rFrMotivo = 'Posizione sommitale/crestale: possibile instabilità locale e caduta massi.';
  } else {
    rFrana = 'R1'; rFrMotivo = 'Morfologia pianeggiante o sub-pianeggiante: rischio frana trascurabile.';
  }

  // --- Rischio globale ---
  const rMap = {R1:1, R2:2, R3:3, R4:4};
  const rGlobNum = Math.max(rMap[rAlluvione], rMap[rFrana]);
  const rGlobale = 'R' + rGlobNum;

  // --- Classe idoneità urbanistica (Circ. 7/LAP) ---
  let classeUrb = 'IIA', classeNote = '';
  if (rGlobNum >= 4) { classeUrb = 'IIIB'; classeNote = 'Aree a pericolosità molto elevata — inedificabile senza specifici interventi di mitigazione'; }
  else if (rGlobNum === 3) { classeUrb = 'IIIA'; classeNote = 'Pericolosità elevata — edificabilità condizionata a specifiche indagini'; }
  else if (rGlobNum === 2) {
    if (morfo === 'pianura' || morfo === 'terrazzo') { classeUrb = 'IIB'; classeNote = 'Pianura con possibile ristagno o ruscellamento superficiale'; }
    else { classeUrb = 'IIA'; classeNote = 'Modesta pericolosità geomorfologica'; }
  } else { classeUrb = 'I'; classeNote = 'Aree senza limitazioni significative'; }

  // --- Indagini consigliate ---
  const profMinima = isAlpino ? 10 : (morfo === 'versante' ? 8 : 5);
  const nProve = rGlobNum >= 3 ? 3 : 2;
  const needMASW = rGlobNum >= 2 || zona === 'Valli Alpine' || zona === 'Canavese';

  // --- Confidenza ---
  const confidenza = (!distAcqua || !quota) ? 'Bassa' : (zona && morfo && pendenza) ? 'Media–Alta' : 'Media';

  // --- Litologia descrizione ---
  const litDesc = {
    ghiaie: 'Depositi ghiaioso-sabbiosi fluvioglaciali o alluvionali (Pleistocene sup.–Olocene). Terreni granulari da sciolti a moderatamente addensati, Nspt tipico 5–40.',
    limi: 'Depositi limoso-argillosi di fondovalle. Terreni coesivi a bassa resistenza, Cu tipico 20–80 kPa, soggetti a cedimenti differenziali e possibile liquefazione se saturi.',
    morenico: 'Depositi morenici eterogenei con clasti cristallini in matrice limoso-sabbiosa. Comportamento geomeccanico variabile; possibili livelli cementati.',
    bedrock: 'Substrato roccioso (gneiss, micascisti, calcescisti o substrato miocenico). Ottima capacità portante, Vs,30 > 500 m/s.',
    colluvio: 'Depositi colluviali di versante a granulometria eterogenea. Suscettibilità a scivolamenti planari e colate detritiche in caso di piogge intense.',
    conoide_det: 'Detrito di conoide torrentizio: ghiaie caotiche con blocchi. Elevata permeabilità, possibile instabilità in presenza di colate rapide.'
  }[litologia] || 'Litologia non specificata.';

  const colMap = {R1:'#22c55e', R2:'#f59e0b', R3:'#f97316', R4:'#ef4444'};
  const badge = r => `<span style="background:${colMap[r]}22;color:${colMap[r]};border:1px solid ${colMap[r]};padding:2px 8px;border-radius:4px;font-weight:700;font-family:monospace">${r}</span>`;

  // Link Claude.ai con prompt precompilato
  const encodedPrompt = encodeURIComponent(promptTesto);
  const claudeUrl = `https://claude.ai/new?q=${encodedPrompt}`;

  return `<div class="pred-result-box">
    <div style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.3);border-radius:6px;padding:0.7rem;margin-bottom:1rem;font-size:0.78rem;color:#93c5fd">
      ℹ Predizione calcolata con motore di inferenza locale basato su regole PAI/geologia piemontese.
      <a href="${claudeUrl}" target="_blank" style="color:#60a5fa;margin-left:0.5rem;font-weight:600">Approfondisci con Claude AI →</a>
    </div>

    <h3>📍 Inquadramento del sito — ${comune}</h3>
    <p><strong>Zona:</strong> ${zona||'Provincia di Torino'} · <strong>Quota:</strong> ${quota||'?'} m s.l.m. · <strong>Morfologia:</strong> ${morfo}</p>
    <p><strong>Litologia attesa:</strong> ${litDesc}</p>

    <h3>⚠ Predizione Rischio PAI</h3>
    <table style="width:100%;border-collapse:collapse;font-size:0.8rem;margin:0.5rem 0">
      <thead><tr>
        <th style="background:#0c1a2e;color:#60a5fa;border:1px solid #1e3a5f;padding:6px 10px;text-align:left">Parametro</th>
        <th style="background:#0c1a2e;color:#60a5fa;border:1px solid #1e3a5f;padding:6px 10px;text-align:left">Valore stimato</th>
        <th style="background:#0c1a2e;color:#60a5fa;border:1px solid #1e3a5f;padding:6px 10px;text-align:left">Motivazione</th>
      </tr></thead>
      <tbody>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px">Rischio Alluvione</td><td style="border:1px solid #1e293b;padding:5px 10px">${badge(rAlluvione)}</td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">${rAlMotivo}</td></tr>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px">Rischio Frana</td><td style="border:1px solid #1e293b;padding:5px 10px">${badge(rFrana)}</td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">${rFrMotivo}</td></tr>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px"><strong>Rischio Globale</strong></td><td style="border:1px solid #1e293b;padding:5px 10px">${badge(rGlobale)}</td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">Valore massimo tra alluvione e frana</td></tr>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px">Classe idoneità urbanistica</td><td style="border:1px solid #1e293b;padding:5px 10px"><strong style="color:#93c5fd">${classeUrb}</strong></td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">${classeNote} (Circ. 7/LAP Regione Piemonte)</td></tr>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px">Fascia PAI probabile</td><td style="border:1px solid #1e293b;padding:5px 10px">${rAlluvione==='R4'?'Fascia A':rAlluvione==='R3'?'Fascia B':rAlluvione==='R2'?'Fascia C':'Fuori fascia'}</td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">Da verificare sulle tavole PAI ufficiali (AdBPo)</td></tr>
        <tr><td style="border:1px solid #1e293b;padding:5px 10px">Confidenza predizione</td><td style="border:1px solid #1e293b;padding:5px 10px;color:${confidenza==='Bassa'?'#ef4444':confidenza.startsWith('Media–')? '#22c55e':'#f59e0b'}">${confidenza}</td><td style="border:1px solid #1e293b;padding:5px 10px;font-size:0.75rem">${!distAcqua||!quota?'Dati incompleti — inserire quota e distanza corso d\'acqua per migliorare la stima':'Basata su morfologia, zona e litologia'}</td></tr>
      </tbody>
    </table>

    <h3>🔩 Indagini consigliate prima del progetto</h3>
    <ul>
      <li><strong>${nProve} prove penetrometriche DPSH</strong> (o SPT) fino a ${profMinima} m dal p.c. — Formula Olandese per Rpd e correlazione Nspt</li>
      ${needMASW ? '<li><strong>1 prospezione sismica MASW</strong> per determinazione Vs,30 e categoria suolo NTC 2018 (obbligatoria in zone sismiche)</li>' : ''}
      ${rFrana >= 'R2' && morfo === 'versante' ? '<li><strong>Rilievo geomorfologico di dettaglio</strong> con mappatura scarpate, lineamenti di frana, gradienti</li>' : ''}
      ${litologia === 'limi' || litologia === 'colluvio' ? '<li><strong>Campionamento indisturbato</strong> per analisi di laboratorio (granulometria, limiti di Atterberg, consolidazione)</li>' : ''}
      <li><strong>Consultazione elaborati PRGC comunale</strong>: carta geologica GB01, carta geomorfologica GB02, carta di sintesi GB06b (Circ. 7/LAP)</li>
    </ul>

    <h3>⚖ Verifiche normative obbligatorie</h3>
    <ul>
      <li>Consultare tavole PAI AdBPo per il foglio relativo a ${comune} — verifica fasce fluviali A/B/C</li>
      <li>Verificare classificazione sismica su <a href="https://www.regione.piemonte.it" target="_blank" style="color:#60a5fa">Regione Piemonte</a> (D.G.R. 6-887/2019)</li>
      <li>Richiedere all'ufficio tecnico comunale carta GB06b di idoneità urbanistica vigente</li>
      <li>Verificare presenza in <a href="https://idrogeo.isprambiente.it/app/" target="_blank" style="color:#60a5fa">IdroGEO ISPRA</a> di fenomeni franosi censiti nel territorio</li>
    </ul>
    <p style="font-size:0.73rem;color:#64748b;margin-top:0.8rem;border-top:1px solid #1e293b;padding-top:0.5rem">
      ⚠ Questa predizione è generata automaticamente da regole deterministiche. Non sostituisce un'indagine geologica professionale in sito. Per qualsiasi finalità progettuale/edilizia è obbligatoria una relazione geologico-tecnica firmata da geologo iscritto all'Albo.
    </p>
  </div>`;
}

function openIndagini(comuneId, nomeComune) {
  const modal = document.getElementById('modal-indagini');
  const title = document.getElementById('modal-indagini-title');
  const body = document.getElementById('modal-indagini-body');
  title.textContent = `📊 Indagini Geotecniche — ${nomeComune}`;

  const comune = (typeof COMUNI_TORINO !== 'undefined' ? COMUNI_TORINO : []).find(c => c.id === comuneId);
  const zona = comune?.zona || '';
  const cargFoglio = (typeof getCARGFoglioUrl === 'function' && comune) ? getCARGFoglioUrl(comune.lat, comune.lng) : null;
  const infoZona = (typeof FONTI_GEOTECNICHE !== 'undefined' && FONTI_GEOTECNICHE.perZona[zona]) ? FONTI_GEOTECNICHE.perZona[zona] : null;
  const fontiNaz = (typeof FONTI_GEOTECNICHE !== 'undefined') ? FONTI_GEOTECNICHE.nazionali : [];
  const fontiReg = (typeof FONTI_GEOTECNICHE !== 'undefined') ? FONTI_GEOTECNICHE.regionali : [];

  body.innerHTML = `
    <div class="ind-intro">
      <p>Le <strong>${comune?.penetrometrie || '?'} prove</strong> nel database RiskMap sono una stima derivata da fonti pubbliche. Il numero reale di indagini disponibili per <strong>${nomeComune}</strong> è significativamente maggiore — consultare le fonti ufficiali elencate di seguito.</p>
      ${infoZona ? `<p style="color:#94a3b8;margin-top:0.5rem"><strong>Zona ${zona}:</strong> ${infoZona.descrizione}</p><p style="color:#10b981;font-size:0.8rem">Stime prove disponibili in zona: <strong>${infoZona.numProveStimate}</strong></p>` : ''}
    </div>

    ${infoZona?.fontiSpecifiche?.length ? `
    <h4 class="ind-section-title">⭐ Fonti specifiche per ${zona}</h4>
    <div class="ind-fonti-grid">
      ${infoZona.fontiSpecifiche.map(f => `
        <a href="${f.url}" target="_blank" class="ind-fonte-card" style="border-color:#065f46">
          <div class="ind-fonte-icon">🎯</div>
          <div>
            <div class="ind-fonte-nome" style="color:#4ade80">${f.nome}</div>
            <div class="ind-fonte-url">${f.url}</div>
          </div>
        </a>`).join('')}
    </div>` : ''}

    <h4 class="ind-section-title" style="margin-top:1.2rem">🌊 Fonti nazionali</h4>
    <div class="ind-fonti-grid">
      ${fontiNaz.map(f => `
        <a href="${f.urlComune ? f.urlComune(comuneId) : f.url}" target="_blank" class="ind-fonte-card">
          <div class="ind-fonte-icon">${f.id==='idrogeo'?'🌊':f.id==='carg_ispra'?'🪨':f.id==='sifrap'?'⛰':'🔬'}</div>
          <div>
            <div class="ind-fonte-nome">${f.nome}</div>
            <div class="ind-fonte-desc">${f.descrizione.substring(0,120)}…</div>
            <div class="ind-fonte-url">${f.urlComune ? f.urlComune(comuneId) : f.url}</div>
          </div>
        </a>`).join('')}
      ${cargFoglio ? `
        <a href="${cargFoglio.url}" target="_blank" class="ind-fonte-card">
          <div class="ind-fonte-icon">📋</div>
          <div>
            <div class="ind-fonte-nome">Carta Geologica — ${cargFoglio.nome}</div>
            <div class="ind-fonte-desc">Foglio specifico per ${nomeComune} — litologia, formazioni, depositi quaternari</div>
            <div class="ind-fonte-url">${cargFoglio.url}</div>
          </div>
        </a>` : ''}
    </div>

    <h4 class="ind-section-title" style="margin-top:1.2rem">🗺 Fonti regionali Piemonte</h4>
    <div class="ind-fonti-grid">
      ${fontiReg.map(f => `
        <a href="${f.urlDiretto || f.urlViewer || f.url}" target="_blank" class="ind-fonte-card">
          <div class="ind-fonte-icon">${f.id==='geoportale_piemonte'?'🗺':f.id==='bdge'?'🗄':f.id==='pai_adbpo'?'⚖':f.id==='arpa_piemonte'?'📡':f.id==='microzonazione'?'〰':f.id==='rpgr'?'📜':'🔗'}</div>
          <div>
            <div class="ind-fonte-nome">${f.nome}</div>
            <div class="ind-fonte-desc">${f.descrizione.substring(0,110)}…</div>
            <div class="ind-fonte-url">${f.urlDiretto || f.urlViewer || f.url}</div>
          </div>
        </a>`).join('')}
      <div class="ind-fonte-card" style="cursor:default;opacity:0.8">
        <div class="ind-fonte-icon">🏛</div>
        <div>
          <div class="ind-fonte-nome">PRGC — Studi geologici comunali</div>
          <div class="ind-fonte-desc">Relazioni geologiche allegate al Piano Regolatore con prove in situ, stratigrafie e classi Circ.7/LAP</div>
          <div class="ind-fonte-url">Ufficio Tecnico Comunale — ${nomeComune} (accesso atti)</div>
        </div>
      </div>
    </div>

    ${comune ? `
    <h4 class="ind-section-title" style="margin-top:1.5rem">📋 Dati RiskMap — ${nomeComune}</h4>
    <table class="ind-table">
      <thead><tr><th>Parametro</th><th>Valore</th><th>Fonte</th></tr></thead>
      <tbody>
        <tr><td>Rischio globale PAI</td><td><strong style="color:${({'R1':'#22c55e','R2':'#f59e0b','R3':'#f97316','R4':'#ef4444'})[comune.rischioGlobale]}">${comune.rischioGlobale}</strong></td><td>PAI AdBPo</td></tr>
        <tr><td>Rischio alluvione</td><td>${comune.rischioAlluvione}</td><td>PAI fasce fluviali</td></tr>
        <tr><td>Rischio frana</td><td>${comune.rischioFrana}</td><td>IFFI / PAI versanti</td></tr>
        <tr><td>Pericolosità idraulica</td><td>${comune.pericoloIdraulico}</td><td>D.Lgs. 49/2010</td></tr>
        <tr><td>N. prove stimate nel DB</td><td>${comune.penetrometrie} ⚠</td><td>Stima aggregata — vedere fonti</td></tr>
        <tr><td>Alluvioni storiche</td><td>${comune.ultimeAlluvioni?.join(', ')||'—'}</td><td>ARPA / Regione</td></tr>
        <tr><td>Frane storiche</td><td>${comune.ultimeFrane?.join(', ')||'—'}</td><td>IFFI ISPRA</td></tr>
        <tr><td>Corsi d'acqua</td><td>${comune.fonteAcqua?.join(', ')||'—'}</td><td>CTR Regione Piemonte</td></tr>
      </tbody>
    </table>
    <p style="font-size:0.72rem;color:#475569;margin-top:0.5rem">⚠ Dati RiskMap aggregati da fonti pubbliche — uso esclusivamente informativo. Per finalità progettuali fare riferimento alle fonti ufficiali.</p>
    ` : ''}
  `;
  modal.style.display = 'flex';
}

function closeIndagini() {
  document.getElementById('modal-indagini').style.display = 'none';
}
// v10 - Mon Mar  9 12:13:24 UTC 2026
