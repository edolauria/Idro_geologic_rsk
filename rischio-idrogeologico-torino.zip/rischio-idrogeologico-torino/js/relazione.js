// ============================================================
// RiskMap TO — Modulo Relazione Geologico-Tecnica
// Generazione file .tex conforme D.M. 17/01/2018 (NTC 2018)
// Struttura basata su relazione geologica professionale (Dott. Nicola Lauria, 2024)
// ============================================================

let relazioneState = {
  step: 1,
  totalSteps: 5,
  dati: {
    committente: '', indirizzo: '', comune: '', mappale: '', foglio: '',
    quotaSlm: '', tipoIntervento: '', descrizioneIntervento: '',
    normativaRif: 'D.M. 17/01/2018', comuneObj: null,
    unitaGeologica: '', litotipo: '', depositoDescrizione: '',
    cartaGeologicaRif: '', classeIdoneitaUrb: '',
    corsoAcquaVicino: '', idrografia: '',
    tipologiaProva: 'DPSH', modelloPenetrometro: 'TG 63-100 EML.C',
    profondita: '', faldaRilevata: false, profondaFalda: '',
    litostratigrafia: [],
    vs30: '', categoriaSubstrato: 'B', categoriaTopo: 'T1',
    zonaSimica: '3', vn: '50', classeUso: 'II',
    liquefazione: 'omessa_comma2', microzonazione: '',
    tipoFondazione: 'platea', pianoPosa: '', larghezza: '', lunghezza: '',
    caricoAmmissibile: '0.5', metodoCalcolo: 'terzaghi_meyerhof',
    geotecnicoNome: '', noteConclusive: '',
    dataRelazione: new Date().toLocaleDateString('it-IT', {month:'long', year:'numeric'})
  },
  relazioneTesto: '',
  loading: false
};

const LITOTIPI_DATABASE = {
  'Anfiteatro Morenico': {
    desc: 'Depositi fluvioglaciali riferiti al Subsintema di Col Gianseco facente parte del Sintema di Frassinere. Di eta\u0300 Pleistocenico superiore, sono costituiti da sabbie ghiaiose e ghiaie sabbiose con clasti eterometrici di quarziti, serpentiniti, gneiss e subordinatamente prasiniti, calcescisti e marmi grigi. Terreni granulari prevalentemente ghiaioso-sabbiosi e sabbioso-ghiaiosi da sciolti a moderatamente addensati.',
    litotipo: 'Depositi fluvioglaciali: sabbie ghiaiose e ghiaie sabbiose',
    carta: 'F\u00b0 155 "Torino Ovest" della Carta Geologica d\'Italia scala 1:50.000',
    classeUrb: 'IIB'
  },
  'Pianura Padana': {
    desc: 'Depositi alluvionali recenti e attuali costituiti da ghiaie, sabbie e limi riferiti ai terrazzi fluviali del Pleistocene superiore\u2013Olocene. Terreni granulari prevalentemente ghiaioso-sabbiosi e sabbioso-ghiaiosi da sciolti a moderatamente addensati, con intercalazioni limoso-argillose.',
    litotipo: 'Alluvioni ghiaiose e sabbiose del fondovalle',
    carta: 'Carta Geologica d\'Italia F\u00b0 56 "Torino" scala 1:100.000',
    classeUrb: 'IIA'
  },
  'Alta Collina': {
    desc: 'Substrato miocenico costituito da marne e arenarie (Formazione di Torino), con copertura colluviale argilloso-limosa di spessore variabile da 1 a 4 m. Terreni a granulometria fine con caratteristiche geotecniche mediocri, localmente interessati da fenomeni di instabilita\u0300 superficiale.',
    litotipo: 'Marne e arenarie mioceniche con copertura colluviale',
    carta: 'Carta Geologica d\'Italia F\u00b0 56 "Torino" scala 1:100.000',
    classeUrb: 'IIIA'
  },
  'Valli Alpine': {
    desc: 'Depositi di conoide torrentizio con ghiaie massive a struttura caotica e matrice sabbiosa. In corrispondenza dei versanti sono presenti depositi di frana a granulometria eterogenea con blocchi decimetrici immersi in matrice fini-granulare. Presenza locale di depositi glaciali e periglaciali.',
    litotipo: 'Depositi di conoide alluvionale con ghiaie e blocchi',
    carta: 'Carta Geologica d\'Italia F\u00b0 154 "Susa" scala 1:50.000',
    classeUrb: 'IIIB'
  },
  'Canavese': {
    desc: 'Depositi fluvioglaciali riferiti all\'Anfiteatro Morenico di Ivrea. Alternanza di ghiaie sabbiose con ciottoli eterometrici di composizione prevalentemente eclogitica e depositi limoso-sabbiosi di raccordo tra i cordoni morenici. Presenza di livelli cementati (conglomerati) a profondita\u0300 variabile.',
    litotipo: 'Depositi fluvioglaciali dell\'Anfiteatro Morenico di Ivrea',
    carta: 'Carta Geologica d\'Italia F\u00b0 42 "Biella" scala 1:50.000',
    classeUrb: 'IIB'
  }
};

function getClassiPAI(comuneObj) {
  if (!comuneObj) return { alluvione: 'R2', frana: 'R1', globale: 'R2', pericoloIdraul: 'P2', pericoloFrana: 'P1' };
  return {
    alluvione: comuneObj.rischioAlluvione || 'R1',
    frana: comuneObj.rischioFrana || 'R1',
    globale: comuneObj.rischioGlobale || 'R1',
    pericoloIdraul: comuneObj.pericoloIdraulico || 'P1',
    pericoloFrana: comuneObj.pericoloFrana || 'P1'
  };
}

function stimaParametri(nspt, litotipo) {
  const n = parseFloat(nspt) || 1;
  const isCoesivo = litotipo && (litotipo.toLowerCase().includes('lim') || litotipo.toLowerCase().includes('argill'));
  let dr = Math.min(100, Math.round(21 * Math.sqrt(n)));
  let phi = Math.round(27.1 + 0.3 * n - 0.00054 * n * n);
  phi = Math.max(17, Math.min(42, phi));
  let e = Math.round(5 * (n + 15));
  let ysat = Math.min(2.1, parseFloat((1.74 + n * 0.01).toFixed(2)));
  let cu = isCoesivo ? parseFloat((0.06 * n).toFixed(2)) : '\u2014';
  return { dr: dr + '%', phi: phi + '\u00b0', e, ysat, cu };
}

// ===================== RENDER WIZARD =====================
function renderRelazioneView() {
  const container = document.getElementById('view-relazione');
  if (!container) return;

  container.innerHTML = `
    <div class="rel-wrapper">
      <div class="rel-header">
        <div class="rel-header-left">
          <div class="rel-logo">\ud83d\udccb</div>
          <div>
            <h2 class="rel-title">Relazione Geologico-Tecnica</h2>
            <p class="rel-subtitle">Generazione file .tex &nbsp;\u00b7&nbsp; D.M. 17/01/2018 (NTC 2018) &nbsp;\u00b7&nbsp; PAI AdBPo &nbsp;\u00b7&nbsp; Circ. 7/LAP</p>
          </div>
        </div>
        <div class="rel-badge-norm">
          <span>PAI AdBPo</span><span>NTC 2018</span><span>Circ. 7/LAP</span>
        </div>
      </div>

      <div class="rel-progress">
        ${[
          {n:1,label:'Committente'},
          {n:2,label:'Geologia & PAI'},
          {n:3,label:'Prove in Sito'},
          {n:4,label:'Sismica'},
          {n:5,label:'Fondazioni'}
        ].map((s,i,arr) => `
          <div class="rel-step-item ${relazioneState.step===s.n?'active':''} ${relazioneState.step>s.n?'done':''}" onclick="goToStep(${s.n})">
            <div class="rel-step-num">${relazioneState.step>s.n?'\u2713':s.n}</div>
            <div class="rel-step-label">${s.label}</div>
          </div>
          ${i<arr.length-1?`<div class="rel-step-connector ${relazioneState.step>s.n?'done':''}"></div>`:''}
        `).join('')}
      </div>

      <div class="rel-body">
        <div class="rel-form-panel" id="rel-form-panel">
          ${renderStep(relazioneState.step)}
        </div>
        <div class="rel-preview-panel" id="rel-preview-panel">
          ${relazioneState.relazioneTesto ? renderPreview() : renderPreviewPlaceholder()}
        </div>
      </div>

      <div class="rel-nav">
        <button class="rel-btn-sec" onclick="prevStep()" ${relazioneState.step===1?'disabled':''}>&#8592; Indietro</button>
        <div class="rel-nav-info">Fase ${relazioneState.step} di ${relazioneState.totalSteps}</div>
        ${relazioneState.step < relazioneState.totalSteps
          ? `<button class="rel-btn-prim" onclick="nextStep()">Avanti &#8594;</button>`
          : `<button class="rel-btn-gen" onclick="generaRelazione()" id="btn-genera" ${relazioneState.loading?'disabled':''}>
              ${relazioneState.loading ? '<span class="rel-spinner"></span> Generazione in corso...' : '\ud83d\udcc4 Genera file .tex'}
            </button>`
        }
      </div>
    </div>
  `;
}

function renderStep(n) {
  const d = relazioneState.dati;
  switch(n) {
    case 1: return renderStep1(d);
    case 2: return renderStep2(d);
    case 3: return renderStep3(d);
    case 4: return renderStep4(d);
    case 5: return renderStep5(d);
    default: return '';
  }
}

// ===================== STEP 1 =====================
function renderStep1(d) {
  return `<div class="rel-step-content">
    <h3 class="rel-section-title">\ud83d\udc64 Committente e Progetto</h3>
    <div class="rel-grid-2">
      <div class="rel-field"><label>Committente / Societa\u0300</label>
        <input type="text" id="f_committente" value="${d.committente}" placeholder="es. CODEMAR s.r.l." oninput="saveField('committente',this.value)"></div>
      <div class="rel-field"><label>Tipo di intervento</label>
        <select id="f_tipoIntervento" onchange="saveField('tipoIntervento',this.value)">
          <option value="" ${!d.tipoIntervento?'selected':''}>&#8212; Seleziona &#8212;</option>
          <option value="nuova_costruzione" ${d.tipoIntervento==='nuova_costruzione'?'selected':''}>Nuova costruzione</option>
          <option value="ristrutturazione" ${d.tipoIntervento==='ristrutturazione'?'selected':''}>Ristrutturazione edilizia</option>
          <option value="ampliamento" ${d.tipoIntervento==='ampliamento'?'selected':''}>Ampliamento edificio esistente</option>
          <option value="cambio_destinazione" ${d.tipoIntervento==='cambio_destinazione'?'selected':''}>Cambio destinazione d'uso</option>
          <option value="variante" ${d.tipoIntervento==='variante'?'selected':''}>Variante urbanistica</option>
          <option value="verifica_sismica" ${d.tipoIntervento==='verifica_sismica'?'selected':''}>Verifica sismica</option>
        </select></div>
    </div>
    <div class="rel-field"><label>Descrizione dell'intervento</label>
      <textarea id="f_descrizioneIntervento" rows="3" placeholder="es. ristrutturazione edilizia con recupero sottotetto a fini abitativi..." oninput="saveField('descrizioneIntervento',this.value)">${d.descrizioneIntervento}</textarea></div>
    <h3 class="rel-section-title" style="margin-top:1.5rem">\ud83d\udccd Localizzazione</h3>
    <div class="rel-grid-3">
      <div class="rel-field"><label>Comune</label>
        <select id="f_comune" onchange="onComuneChange(this.value)">
          <option value="">&#8212; Seleziona comune &#8212;</option>
          ${(typeof COMUNI_TORINO !== 'undefined' ? COMUNI_TORINO : []).map(c => `<option value="${c.id}" ${d.comune===c.id?'selected':''}>${c.nome}</option>`).join('')}
        </select></div>
      <div class="rel-field"><label>Indirizzo / Via</label>
        <input type="text" id="f_indirizzo" value="${d.indirizzo}" placeholder="es. Via Urbino, 4" oninput="saveField('indirizzo',this.value)"></div>
      <div class="rel-field"><label>Quota s.l.m. (m)</label>
        <input type="number" id="f_quotaSlm" value="${d.quotaSlm}" placeholder="es. 350" oninput="saveField('quotaSlm',this.value)"></div>
      <div class="rel-field"><label>Foglio N.C.T.</label>
        <input type="text" id="f_foglio" value="${d.foglio}" placeholder="es. X" oninput="saveField('foglio',this.value)"></div>
      <div class="rel-field"><label>Mappale</label>
        <input type="text" id="f_mappale" value="${d.mappale}" placeholder="es. 412" oninput="saveField('mappale',this.value)"></div>
      <div class="rel-field"><label>Normativa di riferimento</label>
        <input type="text" id="f_normativaRif" value="${d.normativaRif}" oninput="saveField('normativaRif',this.value)"></div>
    </div>
    <div class="rel-grid-2">
      <div class="rel-field"><label>Geologo redattore</label>
        <input type="text" id="f_geotecnicoNome" value="${d.geotecnicoNome}" placeholder="es. Dott. Geol. Nome Cognome" oninput="saveField('geotecnicoNome',this.value)"></div>
      <div class="rel-field"><label>Data relazione</label>
        <input type="text" id="f_dataRelazione" value="${d.dataRelazione}" placeholder="es. settembre 2024" oninput="saveField('dataRelazione',this.value)"></div>
    </div>
  </div>`;
}

// ===================== STEP 2 =====================
function renderStep2(d) {
  const pai = getClassiPAI(d.comuneObj);
  return `<div class="rel-step-content">
    <h3 class="rel-section-title">\ud83d\uddfa Inquadramento Geologico</h3>
    ${d.comuneObj ? `
    <div class="rel-info-box">
      <div class="rel-info-box-title">\ud83d\udcca Dati RiskMap TO &#8212; ${d.comuneObj.nome}</div>
      <div class="rel-pai-grid">
        <div class="rel-pai-item"><span class="rel-pai-label">Rischio Alluvione PAI</span><span class="rel-badge-r ${pai.alluvione.toLowerCase()}">${pai.alluvione}</span></div>
        <div class="rel-pai-item"><span class="rel-pai-label">Rischio Frana PAI</span><span class="rel-badge-r ${pai.frana.toLowerCase()}">${pai.frana}</span></div>
        <div class="rel-pai-item"><span class="rel-pai-label">Pericolosita\u0300 Idraulica</span><span class="rel-badge-p">${pai.pericoloIdraul}</span></div>
        <div class="rel-pai-item"><span class="rel-pai-label">Pericolosita\u0300 Frana</span><span class="rel-badge-p">${pai.pericoloFrana}</span></div>
        <div class="rel-pai-item"><span class="rel-pai-label">Area PAI</span><span class="rel-badge-p">${d.comuneObj.areaPAI?'S\u00ec':'No'}</span></div>
        <div class="rel-pai-item"><span class="rel-pai-label">Zona</span><span class="rel-badge-p">${d.comuneObj.zona}</span></div>
      </div>
      ${d.comuneObj.ultimeAlluvioni?.length?`<div class="rel-eventi">&#9889; Alluvioni storiche: ${d.comuneObj.ultimeAlluvioni.join(', ')}</div>`:''}
      ${d.comuneObj.ultimeFrane?.length?`<div class="rel-eventi">&#9889; Frane storiche: ${d.comuneObj.ultimeFrane.join(', ')}</div>`:''}
    </div>` : `<div class="rel-warning">&#9888; Seleziona un comune nello Step 1 per importare automaticamente i dati PAI dal modello RiskMap.</div>`}
    <div class="rel-grid-2" style="margin-top:1.2rem">
      <div class="rel-field"><label>Contesto geologico prevalente</label>
        <select id="f_unitaGeologica" onchange="onUnitaGeoChange(this.value)">
          <option value="">&#8212; Seleziona &#8212;</option>
          ${Object.keys(LITOTIPI_DATABASE).map(k=>`<option value="${k}" ${d.unitaGeologica===k?'selected':''}>${k}</option>`).join('')}
          <option value="custom" ${d.unitaGeologica==='custom'?'selected':''}>Altro (manuale)</option>
        </select></div>
      <div class="rel-field"><label>Classe idoneita\u0300 urbanistica (Circ. 7/LAP)</label>
        <select id="f_classeIdoneitaUrb" onchange="saveField('classeIdoneitaUrb',this.value)">
          <option value="">&#8212; Seleziona &#8212;</option>
          <option value="I" ${d.classeIdoneitaUrb==='I'?'selected':''}>Classe I &#8212; Senza limitazioni significative</option>
          <option value="IIA" ${d.classeIdoneitaUrb==='IIA'?'selected':''}>Classe IIA &#8212; Modesta pericolosita\u0300</option>
          <option value="IIB" ${d.classeIdoneitaUrb==='IIB'?'selected':''}>Classe IIB &#8212; Ristagno/ruscellamento superficiale</option>
          <option value="IIIA" ${d.classeIdoneitaUrb==='IIIA'?'selected':''}>Classe IIIA &#8212; Pericolosita\u0300 elevata</option>
          <option value="IIIB" ${d.classeIdoneitaUrb==='IIIB'?'selected':''}>Classe IIIB &#8212; Pericolosita\u0300 molto elevata (inedificabile)</option>
        </select></div>
    </div>
    <div class="rel-field"><label>Descrizione depositi (da Carta Geologica)</label>
      <textarea id="f_depositoDescrizione" rows="4" placeholder="Descrizione litologica dettagliata dei depositi..." oninput="saveField('depositoDescrizione',this.value)">${d.depositoDescrizione}</textarea></div>
    <div class="rel-field"><label>Carta geologica di riferimento</label>
      <input type="text" id="f_cartaGeologicaRif" value="${d.cartaGeologicaRif}" placeholder="es. F 155 Torino Ovest CGI 1:50.000" oninput="saveField('cartaGeologicaRif',this.value)"></div>
    <h3 class="rel-section-title" style="margin-top:1.5rem">\ud83d\udca7 Idrografia e Idrogeologia</h3>
    <div class="rel-grid-2">
      <div class="rel-field"><label>Corso d'acqua piu\u0300 vicino</label>
        <input type="text" id="f_corsoAcquaVicino" value="${d.corsoAcquaVicino}" placeholder="es. Fiume Dora Riparia a 2.1 km" oninput="saveField('corsoAcquaVicino',this.value)"></div>
      <div class="rel-field"><label>Idrografia superficiale locale</label>
        <input type="text" id="f_idrografia" value="${d.idrografia}" placeholder="es. canali irrigui, impluvi secondari" oninput="saveField('idrografia',this.value)"></div>
    </div>
  </div>`;
}

// ===================== STEP 3 =====================
function renderStep3(d) {
  const strati = d.litostratigrafia || [];
  return `<div class="rel-step-content">
    <h3 class="rel-section-title">\ud83d\udd29 Prova Penetrometrica Dinamica</h3>
    <div class="rel-grid-3">
      <div class="rel-field"><label>Tipo penetrometro</label>
        <select id="f_tipologiaProva" onchange="saveField('tipologiaProva',this.value)">
          <option value="DPSH" ${d.tipologiaProva==='DPSH'?'selected':''}>DPSH (Super Pesante &ge;60 kg)</option>
          <option value="DPH" ${d.tipologiaProva==='DPH'?'selected':''}>DPH (Pesante 40&ndash;60 kg)</option>
          <option value="DPM" ${d.tipologiaProva==='DPM'?'selected':''}>DPM (Medio 10&ndash;40 kg)</option>
          <option value="DPL" ${d.tipologiaProva==='DPL'?'selected':''}>DPL (Leggero &le;10 kg)</option>
          <option value="SPT" ${d.tipologiaProva==='SPT'?'selected':''}>SPT Standard</option>
          <option value="CPT" ${d.tipologiaProva==='CPT'?'selected':''}>CPT Statica</option>
          <option value="MASW" ${d.tipologiaProva==='MASW'?'selected':''}>MASW Sismica</option>
        </select></div>
      <div class="rel-field"><label>Modello strumento</label>
        <input type="text" id="f_modelloPenetrometro" value="${d.modelloPenetrometro}" placeholder="es. TG 63-100 EML.C" oninput="saveField('modelloPenetrometro',this.value)"></div>
      <div class="rel-field"><label>Profondita\u0300 max (m)</label>
        <input type="number" id="f_profondita" value="${d.profondita}" placeholder="es. 5.40" step="0.1" oninput="saveField('profondita',this.value)"></div>
    </div>
    <div class="rel-grid-2">
      <div class="rel-field"><label>Falda freatica</label>
        <select id="f_faldaRilevata" onchange="onFaldaChange(this.value)">
          <option value="no" ${!d.faldaRilevata?'selected':''}>Non rilevata</option>
          <option value="si" ${d.faldaRilevata?'selected':''}>Rilevata</option>
        </select></div>
      <div class="rel-field" id="falda-depth-field" style="${d.faldaRilevata?'':'opacity:0.4;pointer-events:none'}">
        <label>Profondita\u0300 falda (m da p.c.)</label>
        <input type="number" id="f_profondaFalda" value="${d.profondaFalda}" placeholder="es. 8.5" step="0.1" oninput="saveField('profondaFalda',this.value)"></div>
    </div>
    <h3 class="rel-section-title" style="margin-top:1.5rem">\ud83d\udcd0 Litostratigrafia ricostruita</h3>
    <p class="rel-hint">Inserisci la colonna stratigrafica risultante dalla prova penetrometrica.</p>
    <div id="litostrat-container">${renderLitostratigrafia(strati)}</div>
    <button class="rel-btn-add" onclick="addLitoStrato()">+ Aggiungi strato</button>
    <h3 class="rel-section-title" style="margin-top:1.5rem">\ud83d\udcca Parametri Geotecnici</h3>
    <p class="rel-hint">Stima automatica con correlazioni Terzaghi-Peck (1948, 1967) e D'Apollonia et al. (1970).</p>
    <div id="geotecnico-container">${renderGeotecnico(d)}</div>
  </div>`;
}

function renderLitostratigrafia(strati) {
  if (!strati.length) return `<div class="rel-no-strati">Nessuno strato inserito. Usa il pulsante qui sotto per aggiungere la litostratigrafia.</div>`;
  return `<table class="rel-table">
    <thead><tr><th>Da (m)</th><th>A (m)</th><th>Litotipo</th><th>Nspt</th><th>Rpd (kg/cm&sup2;)</th><th></th></tr></thead>
    <tbody>${strati.map((s,i)=>`
      <tr>
        <td><input type="number" step="0.1" value="${s.da}" onchange="updateStrato(${i},'da',this.value)" class="rel-td-input"></td>
        <td><input type="number" step="0.1" value="${s.a}" onchange="updateStrato(${i},'a',this.value)" class="rel-td-input"></td>
        <td><input type="text" value="${s.litotipo}" onchange="updateStrato(${i},'litotipo',this.value)" class="rel-td-input-wide" placeholder="es. Limi sabbiosi"></td>
        <td><input type="number" step="1" value="${s.nspt}" onchange="updateStrato(${i},'nspt',this.value)" class="rel-td-input"></td>
        <td><input type="number" step="0.1" value="${s.rpd}" onchange="updateStrato(${i},'rpd',this.value)" class="rel-td-input"></td>
        <td><button class="rel-btn-del" onclick="removeStrato(${i})">&times;</button></td>
      </tr>`).join('')}
    </tbody></table>`;
}

function renderGeotecnico(d) {
  const strati = d.litostratigrafia || [];
  if (!strati.length) return `<div class="rel-no-strati">Inserisci prima la litostratigrafia.</div>`;
  return `<table class="rel-table" style="font-size:0.78rem">
    <thead><tr><th>Litologia</th><th>Nspt</th><th>DR (%)</th><th>&phi;' (&deg;)</th><th>E' (kg/cm&sup2;)</th><th>&gamma;sat (t/m&sup3;)</th><th>Cu (kg/cm&sup2;)</th></tr></thead>
    <tbody>${strati.map(s=>{const p=stimaParametri(s.nspt,s.litotipo);return`<tr>
      <td style="font-size:0.75rem">${s.litotipo||'&#8212;'}</td>
      <td>${s.nspt||'&#8212;'}</td><td>${p.dr}</td><td>${p.phi}</td><td>${p.e}</td><td>${p.ysat}</td><td>${p.cu}</td>
    </tr>`;}).join('')}</tbody></table>`;
}

// ===================== STEP 4 =====================
function renderStep4(d) {
  return `<div class="rel-step-content">
    <h3 class="rel-section-title">\ud83c\udf0d Caratterizzazione Sismica (NTC 2018)</h3>
    <div class="rel-info-box">
      <div class="rel-info-box-title">Classificazione sismica Regione Piemonte</div>
      <p style="font-size:0.85rem;color:#94a3b8;margin:0">D.G.R. n. 6-887 del 30/12/2019 aggiorna la classificazione ai sensi di O.P.C.M. 3519/2006: zona sismica 3 (con sottozona 3S) e zona 4.</p>
    </div>
    <div class="rel-grid-3" style="margin-top:1.2rem">
      <div class="rel-field"><label>Zona sismica comunale</label>
        <select id="f_zonaSimica" onchange="saveField('zonaSimica',this.value)">
          <option value="3" ${d.zonaSimica==='3'?'selected':''}>Zona 3</option>
          <option value="3S" ${d.zonaSimica==='3S'?'selected':''}>Zona 3S</option>
          <option value="4" ${d.zonaSimica==='4'?'selected':''}>Zona 4</option>
        </select></div>
      <div class="rel-field"><label>Vs,30 misurato/stimato (m/s)</label>
        <input type="number" id="f_vs30" value="${d.vs30}" placeholder="es. 421" oninput="onVs30Change(this.value)"></div>
      <div class="rel-field"><label>Categoria suolo (Tab. 3.2.II NTC)</label>
        <select id="f_categoriaSubstrato" onchange="saveField('categoriaSubstrato',this.value)">
          <option value="A" ${d.categoriaSubstrato==='A'?'selected':''}>A &#8212; Roccia (Vs &gt; 800 m/s)</option>
          <option value="B" ${d.categoriaSubstrato==='B'?'selected':''}>B &#8212; Depositi duri (360&ndash;800 m/s)</option>
          <option value="C" ${d.categoriaSubstrato==='C'?'selected':''}>C &#8212; Depositi granulari/coesivi (180&ndash;360 m/s)</option>
          <option value="D" ${d.categoriaSubstrato==='D'?'selected':''}>D &#8212; Depositi molli (&lt; 180 m/s)</option>
          <option value="E" ${d.categoriaSubstrato==='E'?'selected':''}>E &#8212; Profili misti</option>
        </select></div>
    </div>
    <div class="rel-grid-3">
      <div class="rel-field"><label>Categoria topografica</label>
        <select id="f_categoriaTopo" onchange="saveField('categoriaTopo',this.value)">
          <option value="T1" ${d.categoriaTopo==='T1'?'selected':''}>T1 &#8212; Pianura</option>
          <option value="T2" ${d.categoriaTopo==='T2'?'selected':''}>T2 &#8212; Pendio &lt;15&deg;</option>
          <option value="T3" ${d.categoriaTopo==='T3'?'selected':''}>T3 &#8212; Rilievo &gt;15&deg;</option>
          <option value="T4" ${d.categoriaTopo==='T4'?'selected':''}>T4 &#8212; Cresta stretta</option>
        </select></div>
      <div class="rel-field"><label>VN &#8212; Vita nominale (anni)</label>
        <select id="f_vn" onchange="saveField('vn',this.value)">
          <option value="10" ${d.vn==='10'?'selected':''}>10 &#8212; Provvisorie</option>
          <option value="50" ${d.vn==='50'?'selected':''}>50 &#8212; Ordinarie</option>
          <option value="100" ${d.vn==='100'?'selected':''}>100 &#8212; Strategiche</option>
        </select></div>
      <div class="rel-field"><label>Classe d'uso</label>
        <select id="f_classeUso" onchange="saveField('classeUso',this.value)">
          <option value="I" ${d.classeUso==='I'?'selected':''}>I (cu = 0.7)</option>
          <option value="II" ${d.classeUso==='II'?'selected':''}>II (cu = 1.0)</option>
          <option value="III" ${d.classeUso==='III'?'selected':''}>III (cu = 1.5)</option>
          <option value="IV" ${d.classeUso==='IV'?'selected':''}>IV (cu = 2.0)</option>
        </select></div>
    </div>
    <h3 class="rel-section-title" style="margin-top:1.5rem">\ud83d\udca7 Verifica Liquefazione (par. 7.11.3.4 NTC 2018)</h3>
    <div class="rel-grid-2">
      <div class="rel-field"><label>Esito verifica</label>
        <select id="f_liquefazione" onchange="saveField('liquefazione',this.value)">
          <option value="omessa_comma2" ${d.liquefazione==='omessa_comma2'?'selected':''}>Omessa &#8212; Falda &gt;15m (comma 2)</option>
          <option value="omessa_comma1" ${d.liquefazione==='omessa_comma1'?'selected':''}>Omessa &#8212; ag &lt;0.1g (comma 1)</option>
          <option value="omessa_comma3" ${d.liquefazione==='omessa_comma3'?'selected':''}>Omessa &#8212; N1(60) &gt;30 (comma 3)</option>
          <option value="condotta" ${d.liquefazione==='condotta'?'selected':''}>Verifica condotta &#8212; nessun rischio</option>
          <option value="rischio" ${d.liquefazione==='rischio'?'selected':''}>Verifica condotta &#8212; rischio accertato</option>
        </select></div>
      <div class="rel-field"><label>Microzonazione sismica (se disponibile)</label>
        <input type="text" id="f_microzonazione" value="${d.microzonazione}" placeholder="es. Zone stabili suscettibili di amplificazione locale" oninput="saveField('microzonazione',this.value)"></div>
    </div>
  </div>`;
}

// ===================== STEP 5 =====================
function renderStep5(d) {
  return `<div class="rel-step-content">
    <h3 class="rel-section-title">\ud83c\udfd7 Dimensionamento Preliminare Fondazioni</h3>
    <div class="rel-grid-3">
      <div class="rel-field"><label>Tipo fondazione</label>
        <select id="f_tipoFondazione" onchange="saveField('tipoFondazione',this.value)">
          <option value="platea" ${d.tipoFondazione==='platea'?'selected':''}>Platea armata</option>
          <option value="trave_rovescia" ${d.tipoFondazione==='trave_rovescia'?'selected':''}>Trave rovescia</option>
          <option value="continua" ${d.tipoFondazione==='continua'?'selected':''}>Fondazione continua</option>
          <option value="isolata" ${d.tipoFondazione==='isolata'?'selected':''}>Plinto isolato</option>
          <option value="pali" ${d.tipoFondazione==='pali'?'selected':''}>Fondazione su pali</option>
        </select></div>
      <div class="rel-field"><label>Piano di posa (m da p.c.)</label>
        <input type="number" id="f_pianoPosa" value="${d.pianoPosa}" step="0.1" placeholder="es. 1.00" oninput="saveField('pianoPosa',this.value)"></div>
      <div class="rel-field"><label>Carico ammissibile (kg/cm&sup2;)</label>
        <input type="number" id="f_caricoAmmissibile" value="${d.caricoAmmissibile}" step="0.05" placeholder="es. 0.5" oninput="saveField('caricoAmmissibile',this.value)"></div>
      <div class="rel-field"><label>Larghezza B (m)</label>
        <input type="number" id="f_larghezza" value="${d.larghezza}" step="0.1" placeholder="es. 3.0" oninput="saveField('larghezza',this.value)"></div>
      <div class="rel-field"><label>Lunghezza L (m)</label>
        <input type="number" id="f_lunghezza" value="${d.lunghezza}" step="0.1" placeholder="es. 16.5" oninput="saveField('lunghezza',this.value)"></div>
      <div class="rel-field"><label>Metodo calcolo capacita\u0300 portante</label>
        <select id="f_metodoCalcolo" onchange="saveField('metodoCalcolo',this.value)">
          <option value="terzaghi_meyerhof" ${d.metodoCalcolo==='terzaghi_meyerhof'?'selected':''}>Terzaghi (1943) + Meyerhof (1953)</option>
          <option value="terzaghi" ${d.metodoCalcolo==='terzaghi'?'selected':''}>Solo Terzaghi (1943)</option>
          <option value="eurocodice7" ${d.metodoCalcolo==='eurocodice7'?'selected':''}>Eurocodice 7</option>
        </select></div>
    </div>
    <div class="rel-field"><label>Note conclusive / prescrizioni aggiuntive</label>
      <textarea id="f_noteConclusive" rows="3" placeholder="Eventuali prescrizioni particolari, necessita\u0300 di approfondimenti..." oninput="saveField('noteConclusive',this.value)">${d.noteConclusive}</textarea></div>
    <div class="rel-generate-box">
      <div class="rel-generate-icon">\ud83d\udcc4</div>
      <div>
        <h4>Pronto per la generazione</h4>
        <p>Verra\u0300 generato un file <strong>.tex</strong> (LaTeX) con la struttura della relazione geologico-tecnica conforme al D.M. 17/01/2018, pronto per la compilazione con pdflatex o Overleaf.</p>
      </div>
    </div>
  </div>`;
}

// ===================== PREVIEW =====================
function renderPreview() {
  return `<div class="rel-preview-header">
    <h3>\ud83d\udcc4 File .tex Generato</h3>
    <div class="rel-preview-actions">
      <button class="rel-btn-copy" onclick="copiaRelazione()">\ud83d\udccb Copia</button>
      <button class="rel-btn-print" onclick="scaricaTex()">&#11015; Scarica .tex</button>
      <button class="rel-btn-regen" onclick="generaRelazione()">\ud83d\udd04 Rigenera</button>
    </div>
  </div>
  <div class="rel-preview-body" id="rel-preview-body" style="font-family:monospace;font-size:0.72rem;white-space:pre;overflow-x:auto;line-height:1.5">${escapeHtml(relazioneState.relazioneTesto)}</div>`;
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function renderPreviewPlaceholder() {
  return `<div class="rel-preview-placeholder">
    <div class="rel-preview-placeholder-icon">\ud83d\udcc4</div>
    <h4>Anteprima file .tex</h4>
    <p>Completa i 5 step e clicca <strong>Genera file .tex</strong> per ottenere il sorgente LaTeX pronto da compilare.</p>
    <div class="rel-preview-features">
      <div>\u2713 Struttura conforme NTC 2018 (12 sezioni)</div>
      <div>\u2713 Frontespizio con dati committente</div>
      <div>\u2713 Tabelle geotecniche M1/M2</div>
      <div>\u2713 Calcoli Terzaghi / Meyerhof</div>
      <div>\u2713 Cedimenti Burland &amp; Burbidge</div>
      <div>\u2713 Parametri sismici e verifica liquefazione</div>
      <div>\u2713 Compilabile con pdflatex / Overleaf</div>
    </div>
  </div>`;
}

// ===================== NAVIGAZIONE =====================
function goToStep(n) {
  if (n <= relazioneState.step) {
    salvaStep();
    relazioneState.step = n;
    renderRelazioneView();
  }
}

function nextStep() {
  salvaStep();
  if (relazioneState.step < relazioneState.totalSteps) {
    relazioneState.step++;
    renderRelazioneView();
    window.scrollTo({top:0,behavior:'smooth'});
  }
}

function prevStep() {
  salvaStep();
  if (relazioneState.step > 1) {
    relazioneState.step--;
    renderRelazioneView();
    window.scrollTo({top:0,behavior:'smooth'});
  }
}

function salvaStep() {
  document.querySelectorAll('#rel-form-panel input, #rel-form-panel select, #rel-form-panel textarea').forEach(el => {
    if (el.id && el.id.startsWith('f_')) {
      const key = el.id.replace('f_', '');
      relazioneState.dati[key] = el.type === 'checkbox' ? el.checked : el.value;
    }
  });
}

function saveField(key, value) { relazioneState.dati[key] = value; }

function onComuneChange(id) {
  relazioneState.dati.comune = id;
  const c = typeof COMUNI_TORINO !== 'undefined' ? COMUNI_TORINO.find(x => x.id === id) : null;
  relazioneState.dati.comuneObj = c || null;
  if (c) relazioneState.dati.quotaSlm = c.altitudine || '';
  renderRelazioneView();
}

function onUnitaGeoChange(key) {
  relazioneState.dati.unitaGeologica = key;
  if (LITOTIPI_DATABASE[key]) {
    const db = LITOTIPI_DATABASE[key];
    relazioneState.dati.depositoDescrizione = db.desc;
    relazioneState.dati.cartaGeologicaRif = db.carta;
    relazioneState.dati.classeIdoneitaUrb = db.classeUrb;
    relazioneState.dati.litotipo = db.litotipo;
  }
  renderRelazioneView();
}

function onFaldaChange(val) {
  relazioneState.dati.faldaRilevata = val === 'si';
  const f = document.getElementById('falda-depth-field');
  if (f) f.style.cssText = val === 'si' ? '' : 'opacity:0.4;pointer-events:none';
}

function onVs30Change(val) {
  const v = parseFloat(val);
  let cat = v > 800 ? 'A' : v >= 360 ? 'B' : v >= 180 ? 'C' : 'D';
  relazioneState.dati.vs30 = val;
  relazioneState.dati.categoriaSubstrato = cat;
  const sel = document.getElementById('f_categoriaSubstrato');
  if (sel) sel.value = cat;
}

function addLitoStrato() {
  if (!relazioneState.dati.litostratigrafia) relazioneState.dati.litostratigrafia = [];
  const strati = relazioneState.dati.litostratigrafia;
  const lastA = strati.length ? parseFloat(strati[strati.length-1].a)||0 : 0;
  strati.push({da: lastA, a: lastA + 1, litotipo: '', nspt: '', rpd: ''});
  const c = document.getElementById('litostrat-container');
  if (c) c.innerHTML = renderLitostratigrafia(strati);
  const g = document.getElementById('geotecnico-container');
  if (g) g.innerHTML = renderGeotecnico(relazioneState.dati);
}

function updateStrato(i, field, value) {
  relazioneState.dati.litostratigrafia[i][field] = value;
  const g = document.getElementById('geotecnico-container');
  if (g) g.innerHTML = renderGeotecnico(relazioneState.dati);
}

function removeStrato(i) {
  relazioneState.dati.litostratigrafia.splice(i, 1);
  const c = document.getElementById('litostrat-container');
  if (c) c.innerHTML = renderLitostratigrafia(relazioneState.dati.litostratigrafia);
}

// ===================== HELPER LaTeX =====================
function texEsc(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/\\/g, '\\textbackslash{}')
    .replace(/&/g, '\\&')
    .replace(/%/g, '\\%')
    .replace(/\$/g, '\\$')
    .replace(/#/g, '\\#')
    .replace(/_/g, '\\_')
    .replace(/\^/g, '\\^{}')
    .replace(/~/g, '\\textasciitilde{}')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}');
}

// ===================== GENERAZIONE TEX =====================
function generaRelazione() {
  salvaStep();
  const d = relazioneState.dati;

  if (!d.committente || !d.comune || !d.tipoIntervento) {
    alert('\u26a0 Compila almeno: Committente, Comune e Tipo intervento prima di generare la relazione.');
    return;
  }

  // Show quick visual feedback on the button without re-rendering
  const btnGenera = document.getElementById('btn-genera');
  if (btnGenera) {
    btnGenera.disabled = true;
    btnGenera.innerHTML = '<span class="rel-spinner"></span> Generazione in corso...';
  }

  // Wrap in setTimeout so the button state updates before heavy work
  setTimeout(() => {
    _generaRelazioneCore();
  }, 30);
}

function _generaRelazioneCore() {
  try {
    _generaRelazioneCoreInternal();
  } catch(err) {
    console.error('[RiskMap] Errore generazione .tex:', err);
    const btnGenera = document.getElementById('btn-genera');
    if (btnGenera) {
      btnGenera.disabled = false;
      btnGenera.innerHTML = '\ud83d\udcc4 Genera file .tex';
    }
    relazioneState.loading = false;
    alert('Errore durante la generazione:\n\n' + err.message + '\n\nControlla la console (F12).');
  }
}

function _generaRelazioneCoreInternal() {
  const d = relazioneState.dati;
console.log("[tex] 1/6 variabili base...");
    const pai = getClassiPAI(d.comuneObj);
  const comuneNome = d.comuneObj ? d.comuneObj.nome : d.comune;
  const cuMap = {I:0.7, II:1, III:1.5, IV:2};
  const vr = parseInt(d.vn) * (cuMap[d.classeUso] || 1);

  // ---- tabella litostratigrafia ----
console.log("[tex] 2/6 strati...");
    const stratiRows = (d.litostratigrafia || []).length > 0
    ? (d.litostratigrafia || []).map(s =>
        `  ${texEsc(s.da)} & ${texEsc(s.a)} & ${texEsc(s.litotipo)} \\\\`
      ).join('\n')
    : '  0.00 & -- & Da inserire \\\\';

  // ---- tabella parametri geotecnici ----
console.log("[tex] 3/6 geoRows...");
    const geoRows = (d.litostratigrafia || []).length > 0
    ? (d.litostratigrafia || []).map(s => {
        const p = stimaParametri(s.nspt, s.litotipo);
        return `  ${texEsc(s.litotipo||'---')} & ${s.nspt||'--'} & ${p.dr} & ${p.phi} & ${p.e} & ${p.ysat} & ${p.cu} \\\\`;
      }).join('\n')
    : '  -- & -- & -- & -- & -- & -- & -- \\\\';

  // ---- testo falda ----
console.log("[tex] 4/6 testi descrittivi...");
    const faldaTesto = d.faldaRilevata
    ? `rilevata a ${texEsc(d.profondaFalda)} m dal piano campagna`
    : `non rilevata nel corso della prova, spinta fino alla profondità massima di ${texEsc(d.profondita || '--')} m dal p.c.`;

  // ---- liquefazione ----
  const liquefazioneMap = {
    omessa_comma2: `La verifica a liquefazione può essere omessa ai sensi del comma~2 del paragrafo~7.11.3.4.2 delle NTC 2018, in quanto la profondità media stagionale della falda è superiore a 15~m dal piano campagna.`,
    omessa_comma1: `La verifica a liquefazione può essere omessa ai sensi del comma~1 del paragrafo~7.11.3.4.2 delle NTC 2018, in quanto le accelerazioni massime attese al piano campagna sono inferiori a 0,1g.`,
    omessa_comma3: `La verifica a liquefazione può essere omessa ai sensi del comma~3 del paragrafo~7.11.3.4.2 delle NTC 2018, in quanto i depositi sono costituiti da sabbie pulite con resistenza penetrometrica normalizzata $(N_1)_{60} > 30$.`,
    condotta: `È stata condotta la verifica a liquefazione ai sensi del paragrafo~7.11.3.4 delle NTC 2018. L'analisi ha evidenziato l'assenza di rischio di liquefazione per i terreni presenti nel sito.`,
    rischio: `È stata condotta la verifica a liquefazione ai sensi del paragrafo~7.11.3.4 delle NTC 2018. L'analisi ha evidenziato la presenza di rischio di liquefazione; si rimanda agli allegati per le misure di mitigazione.`
  };
  const liquefazioneTesto = liquefazioneMap[d.liquefazione] || liquefazioneMap['omessa_comma2'];

  // ---- tipo fondazione ----
  const fondazioneMap = {
    platea: 'platea armata', trave_rovescia: 'trave rovescia', continua: 'fondazione continua',
    isolata: 'plinto isolato', pali: 'fondazione su pali'
  };
  const fondazioneTesto = fondazioneMap[d.tipoFondazione] || d.tipoFondazione;

  // ---- tipo intervento ----
  const interventoMap = {
    nuova_costruzione: 'nuova costruzione', ristrutturazione: 'ristrutturazione edilizia',
    ampliamento: 'ampliamento edilizio', cambio_destinazione: "cambio di destinazione d'uso",
    variante: 'variante urbanistica', verifica_sismica: 'verifica sismica'
  };
  const interventoTesto = interventoMap[d.tipoIntervento] || d.tipoIntervento;

  // ---- metodo calcolo ----
  const metodoTesto = d.metodoCalcolo === 'terzaghi_meyerhof'
    ? 'Terzaghi (1943) e Meyerhof (1953)'
    : d.metodoCalcolo === 'terzaghi' ? 'Terzaghi (1943)' : 'Eurocodice 7';

  const geologo = texEsc(d.geotecnicoNome || 'Dott. Geol. [Nome Cognome]');
  const committente = texEsc(d.committente);
  const comune_tex = texEsc(comuneNome);
  const indirizzo_tex = texEsc(d.indirizzo || '');
  const quota_tex = texEsc(d.quotaSlm || '');
  const mappale_tex = texEsc(d.mappale || '');
  const foglio_tex = texEsc(d.foglio || '');
  const normativa_tex = texEsc(d.normativaRif || 'D.M. 17/01/2018 (NTC 2018)');
  const data_tex = texEsc(d.dataRelazione);
  const desc_tex = texEsc(d.descrizioneIntervento || 'Indagine geologica');
  const deposito_tex = texEsc(d.depositoDescrizione || '');
  const carta_tex = texEsc(d.cartaGeologicaRif || '');
  const corso_acqua_tex = texEsc(d.corsoAcquaVicino || '');
  const idrografia_tex = texEsc(d.idrografia || '');
  const carico_tex = texEsc(d.caricoAmmissibile || '0.5');
  const caricoKpa = Math.round(parseFloat(d.caricoAmmissibile || 0.5) * 100);
  const larghezza_tex = texEsc(d.larghezza || '[B]');
  const lunghezza_tex = texEsc(d.lunghezza || '[L]');
  const pianoPosa_tex = texEsc(d.pianoPosa || '[x,xx]');
  const vs30_tex = texEsc(d.vs30 || '');
  const zona_tex = texEsc(d.zonaSimica);
  const catSubstrato = texEsc(d.categoriaSubstrato);
  const catTopo = texEsc(d.categoriaTopo);
  const vn_tex = texEsc(d.vn);
  const classeUso_tex = texEsc(d.classeUso);
  const microz_tex = texEsc(d.microzonazione || '');
  const classeUrb_tex = texEsc(d.classeIdoneitaUrb || '[classe]');
  const note_tex = texEsc(d.noteConclusive || '');
  const areaPAI = d.comuneObj && d.comuneObj.areaPAI;

console.log("[tex] 5/6 costruzione template...");
  const tex_content = [
    "% ============================================================\n% Relazione Geologico-Tecnica --- RiskMap TO\n% Conforme D.M. 17/01/2018 (NTC 2018), PAI AdBPo, Circ. 7/LAP\n% Generato automaticamente da RiskMap TO\n% Data generazione: ",
    new Date().toLocaleDateString('it-IT'),
    "\n% ============================================================\n\n\\documentclass[12pt,a4paper]{article}\n\n% --- Pacchetti ---\n\\usepackage[utf8]{inputenc}\n\\usepackage[T1]{fontenc}\n\\usepackage[italian]{babel}\n\\usepackage[top=2.5cm,bottom=2.5cm,left=2.5cm,right=2.5cm]{geometry}\n\\usepackage{booktabs}\n\\usepackage{array}\n\\usepackage{multirow}\n\\usepackage{amsmath}\n\\usepackage{graphicx}\n\\usepackage{fancyhdr}\n\\usepackage{titlesec}\n\\usepackage{parskip}\n\\usepackage{caption}\n\\usepackage{hyperref}\n\\usepackage{xcolor}\n\\usepackage{microtype}\n\\usepackage{enumitem}\n\n\\pagestyle{fancy}\n\\fancyhf{}\n\\fancyhead[L]{\\small Relazione Geologico-Tecnica}\n\\fancyhead[R]{\\small\\textit{STUDIO GEOLOGICO ",
    geologo,
    "}}\n\\fancyfoot[C]{\\thepage}\n\\renewcommand{\\headrulewidth}{0.4pt}\n\n\\hypersetup{\n  pdftitle={Relazione Geologico-Tecnica -- ",
    comune_tex,
    "},\n  pdfauthor={",
    geologo,
    "},\n  pdfsubject={Indagine geologica -- ",
    normativa_tex,
    "},\n  colorlinks=true, linkcolor=black, urlcolor=black, citecolor=black\n}\n\n\\begin{document}\n\n% ============================================================\n\\begin{titlepage}\n\\centering\n\\vspace*{2cm}\n{\\large\\textbf{REGIONE PIEMONTE}}\\\\[0.5em]\n{\\normalsize\\textbf{CITT\\`A METROPOLITANA DI TORINO}}\\\\[1.5em]\n{\\LARGE\\textbf{COMUNE DI ",
    comune_tex.toUpperCase(),
    "}}\\\\[2em]\n{\\large\\textit{",
    desc_tex,
    "}}\\\\[1em]\n{\\normalsize ",
    normativa_tex,
    "}\\\\[1.5em]\n\\rule{\\textwidth}{0.5pt}\\\\[1em]\n\\begin{minipage}{0.6\\textwidth}\n  \\raggedright\n  Committente: \\textbf{",
    committente,
    "}\\\\[0.3em]\n",
    (d.indirizzo ? '  Sito: ' + indirizzo_tex + '\\\\[0.3em]\n' : ''),
    "  \\rule{\\textwidth}{0.5pt}\\\\[2em]\n  \\textbf{RELAZIONE GEOLOGICO-TECNICA}\n\\end{minipage}\n\\hfill\n\\begin{minipage}{0.35\\textwidth}\n  \\raggedright\n  \\textbf{STUDIO GEOLOGICO}\\\\\n  ",
    geologo,
    "\n\\end{minipage}\n\\hfill\n\\begin{minipage}{0.35\\textwidth}\n  \\raggedleft\n  \\textit{",
    data_tex,
    "}\n\\end{minipage}\n\n\\vspace{1em}\n\\rule{\\textwidth}{0.4pt}\n\n\\end{titlepage}\n\n% =============================================================\n\\section{PREMESSA}\n% =============================================================\n\nPer conto della ",
    committente,
    " \\`e stata condotta un'indagine geologica riguardante l'area sita\nnel territorio del Comune di ",
    comune_tex,
    " (Citt\\`a Metropolitana di Torino)",
    (d.indirizzo ? ', in ' + indirizzo_tex : ''),
    ",\nal fine di accertare gli eventuali rischi idrogeologici e di fornire\ni parametri geotecnici necessari alla progettazione.\n\nNel sito in esame \\`e in progetto \\textit{",
    interventoTesto,
    "}",
    (d.descrizioneIntervento ? ', che prevede ' + texEsc(d.descrizioneIntervento) : ''),
    ".\n\n\\`E stato pertanto effettuato un sopralluogo geologico dell'area ed eseguita\nun'indagine penetrometrica dinamica di tipo \\textbf{",
    texEsc(d.tipologiaProva),
    "}\ncon penetrometro modello \\textbf{",
    texEsc(d.modelloPenetrometro),
    "}.\n\nI risultati dello studio sono esposti nella presente relazione e negli allegati grafici.\n\nLa presente relazione \\`e redatta in ottemperanza a quanto richiesto\ndalle vigenti leggi, in particolare al ",
    normativa_tex,
    ".\n\nPer quanto riguarda la classificazione sismica, il territorio del Comune di ",
    comune_tex,
    " ricade nella zona sismica~",
    zona_tex,
    ".\n\n\n% =============================================================\n\\section{ASPETTI GEOLOGICI, GEOMORFOLOGICI E IDROGEOLOGICI}\n% =============================================================\n\nL'opera \\`e ubicata nel territorio del Comune di ",
    comune_tex,
    " (Citt\\`a Metropolitana di Torino)",
    (d.indirizzo ? ', in ' + indirizzo_tex : ''),
    ", alla quota di circa ",
    quota_tex,
    "~m~s.l.m.",
    (mappale_tex && foglio_tex ? ', in corrispondenza del mappale~' + mappale_tex + ' del Foglio~' + foglio_tex + ' del N.C.T.' : ''),
    ".\n\n",
    (deposito_tex ? deposito_tex : 'Dal punto di vista geologico l\'area \`e caratterizzata da depositi alluvionali.'),
    "\n\n",
    (carta_tex ? 'Il riferimento cartografico adottato \`e la ' + carta_tex + '.' : ''),
    "\n\n\n% =============================================================\n\\section{ASPETTI IDROLOGICI E IDROGEOLOGICI}\n% =============================================================\n\nNell'immediato intorno dell'area in esame, ",
    (corso_acqua_tex ? 'il corso d\'acqua pi\`u importante nelle vicinanze \`e ' + corso_acqua_tex : 'non sono presenti corsi d\'acqua significativi nelle immediate adiacenze'),
    ".\n\n",
    (idrografia_tex ? 'La zona \`e interessata da ' + idrografia_tex + '.' : ''),
    "\n\nPer quanto riguarda la falda freatica, nel corso della prova penetrometrica\nessa \\`e stata ",
    faldaTesto,
    ".",
    (!d.faldaRilevata ? ' Essa \`e pertanto pi\`u profonda rispetto al piano di imposta della fondazione.' : ''),
    "\n\n\n% =============================================================\n\\section{RISULTATI DELL'INDAGINE}\n% =============================================================\n\n\\subsection{Pericolosit\\`a idrogeologica PAI}\n\nIn accordo con il Piano di Assetto Idrogeologico (PAI) dell'Autorit\\`a di Bacino\ndel Fiume Po, il sito presenta:\n\\begin{itemize}\n  \\item Rischio alluvione: \\textbf{",
    texEsc(pai.alluvione),
    "}\n  \\item Rischio frana: \\textbf{",
    texEsc(pai.frana),
    "}\n  \\item Pericolosit\\`a idraulica: \\textbf{",
    texEsc(pai.pericoloIdraul),
    "}\n  \\item Pericolosit\\`a frana: \\textbf{",
    texEsc(pai.pericoloFrana),
    "}\n  \\item Carta geomorfologica: le analisi non evidenziano fenomeni di instabilit\\`a\n    in atto o potenziale nell'immediato intorno dell'area in esame.",
    (areaPAI ? "\n  \\item L'area ricade nelle tavole PAI." : ''),
    "\n\\end{itemize}\n\n\\subsection{Idoneit\\`a urbanistica -- Circolare 7/LAP}\n\nSi classifica l'edificio in esame in \\textbf{Classe ",
    classeUrb_tex,
    "} della Circolare Regionale n.~7/LAP.\n\n\n% =============================================================\n\\section{RISULTATI DELL'INDAGINE PENETROMETRICA}\n% =============================================================\n\n\\`E stata eseguita un'indagine penetrometrica dinamica con penetrometro di tipo\n\\textbf{",
    texEsc(d.tipologiaProva),
    " ",
    texEsc(d.modelloPenetrometro),
    "},\ndirettamente sull'area interessata dall'intervento.\n\nI risultati della prova penetrometrica sono riportati nella tabella seguente:\n\n\\begin{center}\n\\begin{tabular}{ccl}\n  \\toprule\n  \\textbf{Da (m)} & \\textbf{A (m)} & \\textbf{Litotipo} \\\\\n  \\midrule\n",
    stratiRows,
    "\n  \\bottomrule\n\\end{tabular}\n\\captionof{table}{Litostratigrafia ricavata dalla prova penetrometrica.}\n\\end{center}\n\n\n% =============================================================\n\\section{CARATTERIZZAZIONE GEOTECNICA}\n% =============================================================\n\nI parametri geotecnici sono stati stimati sulla base delle correlazioni\ndi Terzaghi e Peck (1948, 1967) dalla resistenza penetrometrica $N_{SPT}$:\n\n\\begin{center}\n\\begin{tabular}{lcccccc}\n  \\toprule\n  \\textbf{Litotipo} & \\textbf{$N_{SPT}$} & \\textbf{$D_r$ (\\%)} &\n  \\textbf{$\\phi'$ ($^\\circ$)} & \\textbf{$E'$ (kg/cm\\textsuperscript{2})} &\n  \\textbf{$\\gamma_{sat}$ (t/m\\textsuperscript{3})} & \\textbf{$c_u$ (kg/cm\\textsuperscript{2})} \\\\\n  \\midrule\n",
    geoRows,
    "\n  \\bottomrule\n\\end{tabular}\n\\captionof{table}{Parametri geotecnici stimati (correlazioni Terzaghi--Peck).}\n\\end{center}\n\n\n% =============================================================\n\\section{CALCOLO PRELIMINARE DEL CARICO ULTIMO}\n% =============================================================\n\nPer il calcolo del carico ultimo sono state utilizzate le equazioni proposte da ",
    texEsc(metodoTesto),
    ".\n\n\\subsection{Metodo di Terzaghi (1943)}\n\nLa capacit\\`a portante ultima di una fondazione nastriforme \\`e espressa da:\n\\begin{equation}\n  q_u = c\\,N_c + q_0\\,N_q + \\tfrac{1}{2}\\,\\gamma\\,B\\,N_\\gamma\n\\end{equation}\ndove $c$ \\`e la coesione, $q_0 = \\gamma D_f$ la pressione geostatica al piano di posa,\n$B$ la larghezza della fondazione e $N_c$, $N_q$, $N_\\gamma$ i fattori di capacit\\`a portante\n(Terzaghi \\& Peck, 1967).\n\n",
    (d.metodoCalcolo !== 'terzaghi' ? '\\subsection{Metodo di Meyerhof (1953)}\n\nIl metodo introduce fattori correttivi di forma ($s$), profondit\`a ($d$) e inclinazione ($i$):\n\\begin{equation}\n  q_u = c\\,N_c\\,s_c\\,d_c\\,i_c + q_0\\,N_q\\,s_q\\,d_q\\,i_q + \\tfrac{1}{2}\\,\\gamma\\,b\'\\,N_\\gamma\n\\end{equation}\n\n' : ''),
    "\\subsection{Risultati delle simulazioni}\n\nFondazione di tipo \\textit{",
    texEsc(fondazioneTesto),
    "}",
    (d.larghezza && d.lunghezza ? ', dimensioni $B=' + larghezza_tex + '$~m, $L=' + lunghezza_tex + '$~m' : ''),
    ",\npiano di posa a $-",
    pianoPosa_tex,
    "$~m dal piano campagna.\n\nLe simulazioni sono state condotte nelle condizioni M1 (coefficienti parziali unitari)\ne M2 (coefficienti parziali $\\gamma_m$ -- Tabella~6.2.II del D.M.\\ 17/01/2018).\n\n\\begin{center}\n\\begin{tabular}{lcccc}\n  \\toprule\n  \\textbf{Fondazione} & \\textbf{$q_{ult,M1}$} & \\textbf{$q_{ult,M2}$} &\n  \\textbf{$q_{amm,M1}$} & \\textbf{$q_{amm,M2}$} \\\\\n  & \\multicolumn{4}{c}{(kg/cm\\textsuperscript{2})} \\\\\n  \\midrule\n  ",
    texEsc(fondazioneTesto),
    " & [---] & [---] & [---] & [---] \\\\\n  \\bottomrule\n\\end{tabular}\n\\captionof{table}{Carichi ultimi e ammissibili M1/M2. Calcolare con Spettri-NTC.}\n\\end{center}\n\n\n% =============================================================\n\\section{CALCOLO DEI CEDIMENTI}\n% =============================================================\n\nI cedimenti attesi sono stati stimati con il metodo di Burland \\& Burbidge (1983):\n\\begin{equation}\n  I_c = \\frac{1{,}706}{N_{av}^{1{,}4}}\n\\end{equation}\ndove $N_{av}$ \\`e il valore medio di $N_{SPT}$ entro la profondit\\`a di influenza\ndella fondazione. I cedimenti attesi risultano compatibili con i limiti\ndeformativi ammissibili per la tipologia strutturale in progetto.\n\n\n% =============================================================\n\\section{PROSPEZIONE SISMICA MASW}\n% =============================================================\n\nLa velocit\\`a equivalente $V_{s,30}$ \\`e definita dal D.M.\\ 17/01/2018 come:\n\\begin{equation}\n  V_{s,eq} = \\frac{\\displaystyle\\sum_{i=1}^{n} h_i}{\\displaystyle\\sum_{i=1}^{n} \\frac{h_i}{V_{s,i}}}\n\\end{equation}\n\n",
    (vs30_tex ? 'Per il sito in esame \`e stato misurato $V_{s,30} = \\textbf{' + vs30_tex + '~m/s}$,\ncorrispondente alla \\textbf{categoria di suolo ' + catSubstrato + '}' : 'Il valore di $V_{s,30}$ \`e stato stimato indirettamente dalla classificazione litologica;\nsi attribuisce la \\textbf{categoria di suolo ' + catSubstrato + '}'),
    "\n(Tabella~3.2.II -- D.M.\\ 17/01/2018). Categoria topografica: \\textbf{",
    catTopo,
    "}.\n\n\n% =============================================================\n\\section{PARAMETRI SISMICI E CATEGORIA DI SUOLO DI FONDAZIONE}\n% =============================================================\n\nIn conformit\\`a con il D.M.\\ 17/01/2018 \\textit{Norme Tecniche per le Costruzioni},\nsono stati determinati i parametri sismici del sito con il programma Spettri-NTC\n(Consiglio Superiore dei LL.PP.).\n\nLe caratteristiche dell'opera sono:\n\\begin{itemize}\n  \\item Vita nominale: $V_N = $ \\textbf{",
    vn_tex,
    " anni}\n  \\item Classe d'uso: \\textbf{",
    classeUso_tex,
    "} $\\Rightarrow$ $c_u = ",
    (cuMap[d.classeUso]||1),
    "$\n  \\item Vita di riferimento: $V_R = V_N \\cdot c_u = ",
    vr,
    "$ anni\n\\end{itemize}\n\n\\begin{center}\n\\begin{tabular}{lcccc}\n  \\toprule\n  \\textbf{Stato limite} & \\textbf{$T_R$ (anni)} & \\textbf{$a_g/g$} &\n  \\textbf{$F_o$} & \\textbf{$T_C^*$ (s)} \\\\\n  \\midrule\n  SLO (Operativit\\`a)   & [---] & [---] & [---] & [---] \\\\\n  SLD (Danno)           & [---] & [---] & [---] & [---] \\\\\n  SLV (Salvaguardia)    & [---] & [---] & [---] & [---] \\\\\n  SLC (Collasso)        & [---] & [---] & [---] & [---] \\\\\n  \\bottomrule\n\\end{tabular}\n\\captionof{table}{Parametri sismici -- inserire valori da Spettri-NTC.}\n\\end{center}\n\n\\textit{Nota: completare la tabella con i valori ottenuti dal programma Spettri-NTC,\ndisponibile sul portale del Consiglio Superiore dei LL.PP.}\n\n",
    (microz_tex ? '\\noindent L\'analisi della microzonazione sismica colloca il sito in \\textbf{' + microz_tex + '}.\n\n' : ''),
    "\\noindent Il terreno di fondazione appartiene alla \\textbf{categoria~",
    catSubstrato,
    "}, categoria topografica \\textbf{",
    catTopo,
    "}.\n\n\n% =============================================================\n\\section{VERIFICA A LIQUEFAZIONE}\n% =============================================================\n\nLa verifica a liquefazione \\`e disciplinata dal par.~7.11.3.4 delle NTC 2018.\nI terreni suscettibili di liquefazione sono sabbie e limi saturi con\ncontenuto di fini $<15\\%$ e $N_{SPT} < 5{,}5\\div6{,}0$.\n\n",
    liquefazioneTesto,
    "\n\n\n% =============================================================\n\\section{CONCLUSIONI}\n% =============================================================\n\nSulla base delle indagini eseguite si conclud\\`e quanto segue:\n\\begin{itemize}\n  \\item Il sito ricade nel Comune di ",
    comune_tex,
    "; l'edificio \\`e classificato in \\textbf{Classe ",
    classeUrb_tex,
    "} (Circ.\\ Reg.\\ n.~7/LAP).\n  \\item I depositi presenti sono: ",
    texEsc(d.litotipo || 'depositi con caratteristiche descritte nelle sezioni precedenti'),
    ".\n  \\item La fondazione dovr\\`a essere di tipo \\textit{",
    texEsc(fondazioneTesto),
    "}, impostata a $-",
    pianoPosa_tex,
    "$~m dal p.c.\n  \\item Il carico ammissibile indicativo \\`e \\textbf{",
    carico_tex,
    "~kg/cm\\textsuperscript{2}} (",
    caricoKpa,
    "~kPa).\n  \\item Categoria sismica del suolo: \\textbf{",
    catSubstrato,
    "}, categoria topografica \\textbf{",
    catTopo,
    "}.\n\\end{itemize}\n\n",
    (note_tex ? note_tex + '\n\n' : ''),
    "Durante le fasi esecutive si raccomanda la presenza di un tecnico abilitato\nper il controllo geotecnico e per segnalare eventuali situazioni impreviste\n(manufatti sotterranei, blocchi rocciosi, ecc.).\n\n\\vspace{2em}\n\\noindent ",
    comune_tex,
    ", \\textit{",
    data_tex,
    "}\n\n\\vspace{3em}\n\\noindent \\textit{",
    geologo,
    "}\n\n\\end{document}\n",
  ].join('');

console.log("[tex] 6/6 completato!");
    relazioneState.relazioneTesto = tex_content;
  relazioneState.loading = false;
  renderRelazioneView();
  setTimeout(() => document.getElementById('rel-preview-panel')?.scrollIntoView({ behavior: 'smooth' }), 300);
}

// ===================== OUTPUT =====================
function copiaRelazione() {
  const testo = relazioneState.relazioneTesto;
  if (!testo) return;
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.querySelector('.rel-btn-copy');
    if (btn) { btn.textContent = '\u2713 Copiato!'; setTimeout(()=>btn.textContent='\ud83d\udccb Copia', 2000); }
  });
}

function scaricaTex() {
  const testo = relazioneState.relazioneTesto;
  if (!testo) return;
  const d = relazioneState.dati;
  const comuneNome = d.comuneObj ? d.comuneObj.nome : (d.comune || 'relazione');
  const nomeFile = 'relazione_geologica_' + comuneNome.toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9_]/g,'') + '.tex';

  // 1. Download nel browser (funziona sempre, anche su file://)
  const blob = new Blob([testo], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = nomeFile;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(blobUrl);

  // 2. Salvataggio su disco tramite server (solo se disponibile)
  if (window.location.protocol !== 'file:') {
    fetch('/api/salva-tex', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nomeFile, contenuto: testo })
    })
    .then(r => r.json())
    .then(data => {
      if (data.ok) {
        _mostraNotificaSalvataggio(`\u2705 Salvato anche su disco: ${data.percorso}`);
      }
    })
    .catch(() => {
      // Silenzioso: il download browser è già avvenuto
    });
  }
}

function _mostraNotificaSalvataggio(messaggio) {
  // Mostra una notifica temporanea in basso a destra
  let notifica = document.getElementById('tex-save-notifica');
  if (!notifica) {
    notifica = document.createElement('div');
    notifica.id = 'tex-save-notifica';
    notifica.style.cssText = [
      'position:fixed', 'bottom:1.5rem', 'right:1.5rem', 'z-index:9999',
      'background:#0f2a1a', 'border:1px solid #22c55e', 'color:#4ade80',
      'padding:0.7rem 1.2rem', 'border-radius:8px', 'font-size:0.82rem',
      'box-shadow:0 4px 20px rgba(0,0,0,0.4)', 'transition:opacity 0.4s'
    ].join(';');
    document.body.appendChild(notifica);
  }
  notifica.textContent = messaggio;
  notifica.style.opacity = '1';
  clearTimeout(notifica._timer);
  notifica._timer = setTimeout(() => {
    notifica.style.opacity = '0';
    setTimeout(() => notifica.remove(), 400);
  }, 4000);
}
