# RiskMap TO — Rischio Idrogeologico Provincia di Torino
### v4.0 — 299 comuni · Layer WMS geologici · AI predittiva · Eseguibile desktop

---

## Avvio rapido

### Modo 1 — Solo mappa (nessuna installazione)
Apri `index.html` nel browser. Funzionano mappa, filtri, schede comuni, predizioni algoritmiche, indagini geotecniche.

### Modo 2 — Con AI (Node.js, nessun build)
```bash
export ANTHROPIC_API_KEY=sk-ant-api03-...    # Mac/Linux
set ANTHROPIC_API_KEY=sk-ant-api03-...       # Windows
node server.js
# poi: http://localhost:3000
```

### Modo 3 — App desktop nativa (Electron)
```bash
npm install          # Prima volta, scarica ~100MB
npm start            # Avvia app desktop

# Build installer:
./build.sh           # Mac/Linux (interattivo)
build.bat            # Windows
```

---

## Layer WMS sulla mappa (attivabili con un click)

| Layer | Fonte |
|---|---|
| PAI Fasce fluviali (A/B/C) | Geoportale Regione Piemonte |
| Frane IFFI | Regione Piemonte / ISPRA |
| Carta Geologica CARG 1:50.000 | ISPRA |
| Ombreggiatura DEM | Esri |

---

## Fonti dati geotecniche

Tutte accessibili cliccando "Indagini geotecniche" nella scheda comune.

- IdroGEO ISPRA: idrogeo.isprambiente.it (frane + alluvioni per comune)
- CARG ISPRA: carta geologica 1:50.000 con note illustrative
- SIFRaP ARPA: inventario frane Piemonte
- GeoPortale Piemonte: 200+ layer GIS regionali
- BDGE Regione: archivio sondaggi, CPT, DPSH, MASW
- PAI AdBPo: fasce fluviali e rischio R1-R4 ufficiali
- ARPA Piemonte: monitoring dissesti, bollettini allerta
- Microzonazione sismica: studi MS1/MS2/MS3 per comune

---

## Build eseguibile

```bash
# Windows
npm install && npm run build:win
# → dist/RiskMap TO Setup 4.0.0.exe

# macOS
npm install && npm run build:mac
# → dist/RiskMap TO 4.0.0.dmg

# Linux
npm install && npm run build:linux
# → dist/RiskMap TO 4.0.0.AppImage
```

Requisito: Node.js >= 16 (nodejs.org) + connessione internet per npm install.

---

## Normativa

PAI AdBPo · Circ. 7/LAP · D.Lgs. 49/2010 · NTC 2018 (D.M. 17/01/2018) · D.G.R. 6-887/2019

*Uso informativo. Per finalità progettuali fare riferimento alle tavole PAI ufficiali e agli strumenti urbanistici comunali vigenti.*
