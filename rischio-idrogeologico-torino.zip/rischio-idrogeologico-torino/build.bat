@echo off
REM ============================================================
REM RiskMap TO — Build Eseguibile Desktop (Windows)
REM ============================================================

echo.
echo   ╔══════════════════════════════════════════════╗
echo   ║   🗺  RiskMap TO — Build Eseguibile          ║
echo   ╚══════════════════════════════════════════════╝
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo   ERRORE: Node.js non trovato.
    echo   Scarica e installa da: https://nodejs.org
    pause
    exit /b 1
)

echo   Node.js: OK
echo   npm: OK
echo.
echo   Installazione dipendenze...
echo   (Prima volta: scarica ~100MB, attendere)
echo.
call npm install

echo.
echo   Scelta build:
echo   1) Windows .exe installer
echo   2) Avvio diretto (senza build)
echo.
set /p choice="  Scelta [1/2]: "

if "%choice%"=="1" (
    echo   Build Windows in corso...
    call npm run build:win
    echo.
    echo   Eseguibile pronto in: dist\
    echo   Installa "RiskMap TO Setup X.X.X.exe" sul tuo PC
) else (
    echo   Avvio applicazione...
    call npm start
)

pause
