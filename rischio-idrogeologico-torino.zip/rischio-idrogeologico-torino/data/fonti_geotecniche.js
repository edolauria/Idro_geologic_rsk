/**
 * FONTI_GEOTECNICHE — Database sorgenti dati ufficiali per indagini geotecniche
 * Provincia di Torino / Piemonte
 * 
 * Tutte le fonti sono pubbliche e ad accesso libero.
 * Aggiornamento: marzo 2025
 */

const FONTI_GEOTECNICHE = {

  // ─── NAZIONALI ────────────────────────────────────────────────────────────
  nazionali: [
    {
      id: "idrogeo",
      nome: "IdroGEO — ISPRA",
      sottotitolo: "Inventario Nazionale Fenomeni Franosi e Alluvioni",
      url: "https://idrogeo.isprambiente.it/app/",
      urlComune: (istat) => `https://idrogeo.isprambiente.it/app/comune/IT${istat}`,
      descrizione: "Piattaforma ISPRA con inventario completo di frane, alluvioni, conoidi, aree esondabili. Per ogni comune: scheda dettagliata con numero e tipo di fenomeni censiti, superficie interessata, eventi storici, link a studi disponibili. Contiene dati IFFI (Inventario dei Fenomeni Franosi in Italia) e SICI (Sistema Informativo sulle Catastrofi Idrogeologiche).",
      tipo: "WebGIS + Database",
      dati: ["Frane (inventario IFFI)", "Alluvioni storiche", "Conoidi torrentizi", "Aree esondabili", "Statistiche per comune e per bacino"],
      aggiornamento: "Continuo (dati ISPRA)",
      accesso: "Libero, nessuna registrazione"
    },
    {
      id: "carg_ispra",
      nome: "Carta Geologica d'Italia 1:50.000 — ISPRA CARG",
      sottotitolo: "Progetto CARG — Cartografia Geologica Nazionale",
      url: "https://www.isprambiente.gov.it/it/progetti/suolo-e-territorio-1/la-carta-geologica-ditalia-alla-scala-1-a-50-000",
      urlWMS: "https://services.isprambiente.it/arcgis/services/CARG/CARG_Sched_1_50000/MapServer/WMSServer",
      urlDownload: "https://www.isprambiente.gov.it/Media/carg/piemonte.html",
      descrizione: "Carta geologica ufficiale in scala 1:50.000 con descrizione di formazioni, età, litologia, strutture tettoniche. Per il Piemonte: Fogli 154 Susa, 155 Torino Ovest, 156 Torino Est, 157 Chivasso, 174 Pinerolo, 155-IV Rivoli. Ogni foglio include note illustrative con descrizione dettagliata delle formazioni.",
      tipo: "Cartografia + WMS",
      dati: ["Formazioni geologiche", "Strutture tettoniche", "Depositi quaternari", "Note illustrative"],
      fogli_torino: [
        { id: "155", nome: "Torino Ovest", url: "https://www.isprambiente.gov.it/Media/carg/155_TORINO_OVEST/Foglio.html" },
        { id: "156", nome: "Torino Est / Chivasso", url: "https://www.isprambiente.gov.it/Media/carg/156_TORINO_EST/Foglio.html" },
        { id: "154", nome: "Susa", url: "https://www.isprambiente.gov.it/Media/carg/154_SUSA/Foglio.html" },
        { id: "174", nome: "Pinerolo", url: "https://www.isprambiente.gov.it/Media/carg/174_PINEROLO/Foglio.html" },
        { id: "142", nome: "Ivrea / Canavese", url: "https://www.isprambiente.gov.it/Media/carg/142_IVREA/Foglio.html" },
      ],
      accesso: "WMS libero; PDF fogli liberi"
    },
    {
      id: "sifrap",
      nome: "SIFRaP — ISPRA",
      sottotitolo: "Sistema Informativo sulle Frane in Piemonte",
      url: "https://sifrap.arpa.piemonte.it/",
      descrizione: "Sistema informativo regionale sulle frane, gestito da ARPA Piemonte in accordo con ISPRA. Contiene mappatura aggiornata dei fenomeni franosi, cronistoria degli eventi, dati pluviometrici correlati. Possibilità di interrogazione per comune, bacino idrografico e tipo di movimento.",
      tipo: "WebGIS",
      dati: ["Frane attive e quiescenti", "Tipologia movimento (crollo, scivolamento, colata)", "Data primo rilevamento", "Stato attività"],
      accesso: "Libero"
    },
    {
      id: "ithaca",
      nome: "ITHACA — IT.Hazard Assessment of Capable faults",
      sottotitolo: "Catalogo delle faglie capaci — ISPRA",
      url: "https://www.isprambiente.gov.it/it/progetti/suolo-e-territorio-1/ithaca-catalogo-delle-faglie-capaci",
      descrizione: "Catalogo italiano delle faglie tettoniche attive e capaci. Rilevante per la valutazione del rischio sismico locale e la pianificazione di fondazioni in prossimità di strutture tettoniche. Per la Provincia di Torino: sistemi di faglie della Valle Susa e Canavese.",
      tipo: "Database",
      dati: ["Faglie attive", "Faglie capaci", "Lunghezza, orientazione, cinematica"],
      accesso: "Libero"
    }
  ],

  // ─── REGIONALI PIEMONTE ───────────────────────────────────────────────────
  regionali: [
    {
      id: "geoportale_piemonte",
      nome: "GeoPortale Piemonte",
      sottotitolo: "Sistema Informativo Territoriale — Regione Piemonte",
      url: "https://www.geoportale.piemonte.it/cms/",
      urlViewer: "https://www.geoportale.piemonte.it/visregpigo/",
      urlGeocatalogo: "https://www.geoportale.piemonte.it/geocatalogo/",
      urlWMS: "https://www.geoportale.piemonte.it/cms/servizi/catalogo-dei-servizi-wms",
      descrizione: "Portale GIS della Regione Piemonte con oltre 200 layer geografici consultabili. Layer rilevanti per indagini geotecniche: carta geologica regionale, carta geomorfologica, carta litotecnica, inventario frane (IFFI), fasce fluviali PAI, microzonazione sismica, perimetrazione aree alluvionabili.",
      tipo: "WebGIS + WMS + Download",
      dati: [
        "Carta Geologica Regionale 1:25.000 e 1:250.000",
        "Carta Geomorfologica",
        "Carta Litotecnica",
        "Inventario Frane IFFI (aggiornato)",
        "Fasce PAI (A, B, C)",
        "Aree in dissesto R1–R4",
        "Microzonazione sismica (dove disponibile)",
        "DTM 5m e 10m (modello digitale del terreno)",
        "Ortofoto storiche e recenti",
        "Carta dei suoli"
      ],
      accesso: "Libero, WMS pubblici"
    },
    {
      id: "bdge",
      nome: "BDGE — Banca Dati Geologica e Geotecnica",
      sottotitolo: "Regione Piemonte — Direzione Ambiente, Governo e Tutela del Territorio",
      url: "https://www.geoportale.piemonte.it/geocatalogo/",
      urlDiretto: "https://www.regione.piemonte.it/web/temi/ambiente-territorio/geologia-geochimica-georisorse/banca-dati-geologica-e-geotecnica",
      descrizione: "Archivio regionale di indagini geognostiche: sondaggi a carotaggio continuo, prove penetrometriche statiche (CPT) e dinamiche (DPSH, SPT), analisi di laboratorio, prove geofisiche (MASW, Down-hole, Cross-hole). Dati raccolti da studi geologici allegati a varianti PRG e piani urbanistici comunali dal 1980 ad oggi. Ricercabile per comune, coordinata e tipo di prova.",
      tipo: "Database + Download",
      dati: [
        "Sondaggi a carotaggio continuo",
        "Prove penetrometriche DPSH, DPH, SPT",
        "Prove CPT statiche",
        "Analisi granulometriche e di laboratorio",
        "Prove geofisiche MASW, HVSR (Nakamura)",
        "Stratigrafie e litologie",
        "Falda freatica rilevata"
      ],
      note: "Per accedere alle singole prove: Geocatalogo → Geotecnica → seleziona comune e area",
      accesso: "Libero previa consultazione"
    },
    {
      id: "pai_adbpo",
      nome: "PAI — Piano di Assetto Idrogeologico",
      sottotitolo: "Autorità di Bacino Distrettuale del Po",
      url: "https://pai.adbpo.it/",
      urlWebGIS: "https://pai.adbpo.it/accesso-allarea-webgis-atlante-dei-piani/",
      urlTavole: "https://pai.adbpo.it/piano-stralcio-per-lassetto-idrogeologico/la-normativa/",
      descrizione: "Piano ufficiale che definisce le fasce di pertinenza fluviale A (Tr≤20 anni), B (Tr≤100 anni), C (Tr≤500 anni) e la classificazione delle aree a rischio R1-R4 per tutto il bacino del Po. Tavole di pericolosità e rischio consultabili per foglio IGM. Include la Direttiva Alluvioni (D.Lgs. 49/2010) con mappe di pericolosità P1/P2/P3.",
      tipo: "WebGIS + Tavole PDF",
      dati: [
        "Fasce fluviali A, B, C",
        "Aree rischio R1, R2, R3, R4",
        "Pericolosità idraulica P1–P4",
        "Perimetrazione aree esondabili",
        "Norme di attuazione per fascia"
      ],
      accesso: "Libero"
    },
    {
      id: "arpa_piemonte",
      nome: "ARPA Piemonte — Geologia e Dissesto",
      sottotitolo: "Agenzia Regionale per la Protezione Ambientale del Piemonte",
      url: "https://www.arpa.piemonte.it/temi/geologia-dissesto",
      urlFrane: "https://www.arpa.piemonte.it/temi/geologia-dissesto/frane-dissesto",
      urlSismico: "https://www.arpa.piemonte.it/temi/geologia-dissesto/pericolosita-sismica",
      urlMonitoraggio: "https://www.arpa.piemonte.it/temi/geologia-dissesto/monitoraggio-frane",
      descrizione: "ARPA Piemonte gestisce il monitoraggio in tempo reale dei fenomeni di dissesto idrogeologico, la rete di sensori idrometeorologici, e produce bollettini di allerta. Disponibili: dati meteoidrologici storici, archivio eventi di dissesto, report annuali sul dissesto idrogeologico piemontese, dati di microzonazione sismica per i comuni del Piemonte.",
      tipo: "Monitoring + Database + Report",
      dati: [
        "Monitoraggio frane in tempo reale",
        "Rete pluviometrica e idrometrica",
        "Bollettini allerta idrogeologica",
        "Archivio eventi storici di dissesto",
        "Microzonazione sismica (MS1, MS2, MS3)",
        "Accelerogrammi sismici registrati",
        "Report annuali sul dissesto"
      ],
      accesso: "Libero"
    },
    {
      id: "microzonazione",
      nome: "Microzonazione Sismica Piemonte",
      sottotitolo: "Regione Piemonte / DPC — Studi di livello MS1, MS2, MS3",
      url: "https://www.regione.piemonte.it/web/temi/protezione-civile-difesa-suolo-opere-pubbliche/protezione-civile/prevenzione-rischi/rischio-sismico/microzonazione-sismica",
      urlViewer: "https://www.geoportale.piemonte.it/visregpigo/",
      descrizione: "Studi di microzonazione sismica realizzati per i comuni a maggiore pericolosità. Livello MS1: analisi geologico-tecnica di primo livello con carta delle microzone omogenee in prospettiva sismica (MOPS). Livello MS2-MS3: modellazioni numeriche con spettri sito-dipendenti. Per la Provincia di Torino: studi disponibili per Valle Susa, Pinerolese, Canavese.",
      tipo: "Report + GIS",
      dati: [
        "Carte MOPS (Microzone Omogenee Prospettiva Sismica)",
        "Profili Vs (velocità onde di taglio)",
        "Fattori di amplificazione locale",
        "Categorie di sottosuolo NTC 2018",
        "Spettri di risposta sito-dipendenti"
      ],
      accesso: "Libero — scaricabile dal GeoPortale"
    },
    {
      id: "rpgr",
      nome: "RPGR — Rischio Piemonte: Gestione del Rischio",
      sottotitolo: "Regione Piemonte — Protezione Civile",
      url: "https://www.regione.piemonte.it/web/temi/protezione-civile-difesa-suolo-opere-pubbliche/difesa-suolo",
      urlPAI: "https://www.regione.piemonte.it/web/temi/protezione-civile-difesa-suolo-opere-pubbliche/difesa-suolo/strumenti-per-difesa-suolo/piano-per-lassetto-idrogeologico-pai",
      urlCirc7: "https://www.regione.piemonte.it/web/temi/protezione-civile-difesa-suolo-opere-pubbliche/difesa-suolo/strumenti-per-difesa-suolo/circolare-7-lap",
      descrizione: "Sezione della Regione Piemonte dedicata alla difesa del suolo. Contiene: testo aggiornato della Circolare 7/LAP con classi di idoneità urbanistica (I, II, IIA, IIB, III, IIIA, IIIB), norme PAI, moduli per pareri geologici, linee guida per la redazione di studi geologici a supporto degli strumenti urbanistici comunali.",
      tipo: "Normativa + Guide",
      dati: [
        "Circolare 7/LAP — Testo integrale",
        "Classi idoneità urbanistica I–IIIB",
        "Guide per studi geologici PRG/PGT",
        "Moduli parere geologico",
        "Normativa PAI e varianti"
      ],
      accesso: "Libero"
    }
  ],

  // ─── COMUNALI / URBANISTICA ────────────────────────────────────────────────
  comunali: [
    {
      id: "prgc",
      nome: "PRGC — Piano Regolatore Generale Comunale",
      sottotitolo: "Uffici Tecnici Comunali — Varianti con Relazione Geologica",
      descrizione: "Ogni comune deve allegare al PRGC una Relazione Geologica (ai sensi della Circolare 7/LAP Regione Piemonte) con carta geologica, geomorfologica e delle classi di idoneità urbanistica. Queste relazioni contengono prove geotecniche in situ, stratigrafie e classificazione PAI del territorio. Richiedere all'Ufficio Tecnico Comunale gli elaborati geologici allegati alla variante generale e alle varianti specifiche.",
      tipo: "Documento tecnico",
      dati: [
        "Carta geologica comunale",
        "Carta geomorfologica",
        "Carta classi idoneità urbanistica (I–IIIB)",
        "Prove penetrometriche e sondaggi",
        "Relazione idrogeologica",
        "Verifiche di stabilità versanti"
      ],
      comeAccedere: "Ufficio Tecnico del Comune → SUAP/SUE → richiesta accesso atti",
      accesso: "Accesso atti — gratuito per professionisti abilitati"
    },
    {
      id: "suap",
      nome: "MUDE Piemonte — SUE/SUAP",
      sottotitolo: "Sportello Unico Edilizia / Attività Produttive Piemonte",
      url: "https://www.sistemapiemonte.it/cms/privati/urbanistica-e-paesaggio",
      descrizione: "Piattaforma regionale per la presentazione digitale di pratiche edilizie. Contiene l'archivio delle pratiche pregresse con allegati tecnici (relazioni geologiche, perizie, prove geotecniche) per la Provincia di Torino. Accessibile ai professionisti abilitati per consultare pratiche relative a immobili specifici.",
      tipo: "Archivio digitale",
      accesso: "Professionisti abilitati con autenticazione SPID/CIE"
    }
  ],

  // ─── ARCHIVI STORICI ──────────────────────────────────────────────────────
  storici: [
    {
      id: "agip_eni",
      nome: "Archivio pozzi AGIP/ENI — Banca Dati Sottosuolo",
      sottotitolo: "MISE / UNMIG — Ufficio Nazionale Minerario Idrocarburi e Georisorse",
      url: "https://unmig.mise.gov.it/unmig/pozzi/ricerca.asp",
      descrizione: "Archivio dei pozzi per idrocarburi ed esplorativi realizzati in Italia. Nella pianura padana torinese sono presenti numerosi pozzi con stratigrafie profonde fino a centinaia di metri, utili per la caratterizzazione del sottosuolo profondo. Dati scaricabili in formato LAS (log geofisici).",
      tipo: "Database",
      dati: ["Stratigrafie pozzi", "Log geofisici (gamma-ray, resistività)", "Test di falda"],
      accesso: "Libero previa registrazione"
    },
    {
      id: "servizio_geologico",
      nome: "Servizio Geologico d'Italia — Archivio storico",
      sottotitolo: "ISPRA — ex Servizio Geologico",
      url: "https://www.isprambiente.gov.it/it/servizi/cartografia/fogli-storici-della-carta-geologica-ditalia",
      descrizione: "Archivio delle carte geologiche storiche della Provincia di Torino in scala 1:100.000 e 1:25.000 realizzate dal Servizio Geologico d'Italia tra il 1880 e il 1970. Utili per confronto storico e per aree non ancora coperte dalla nuova CARG 1:50.000.",
      tipo: "Cartografia storica",
      accesso: "Libero — download PDF"
    }
  ],

  // ─── INDAGINI PER ZONA GEOGRAFICA ────────────────────────────────────────
  perZona: {
    "Torino": {
      descrizione: "La città di Torino è posta su terrazza fluvioglaciale a -1/-3m su alluvioni ghiaiose-sabbiose del Po. Substrato: depositi fluvioglaciali würmiani (ghiaie con matrice sabbiosa, Dr>60%), livello falda a 5-15m di profondità variabile stagionalmente. Disponibili numerose stratigrafie da cantieri metropolitani (Metro linea 1 e 2) e da interventi edilizi.",
      numProveStimate: "500+",
      fontiSpecifiche: [
        { nome: "Studi Metropolitana Torino (GTT)", url: "https://www.gtt.to.it/cms/mobilita/metropolitana" },
        { nome: "BDGE Regione Piemonte — Torino", url: "https://www.geoportale.piemonte.it/geocatalogo/" }
      ]
    },
    "Canavese": {
      descrizione: "L'Anfiteatro Morenico di Ivrea è caratterizzato da depositi morenici eterogenei (Subsintema Col Gianseco, Sintema Frassinere — Pleistocene sup.) con diamicton, ghiaie e sabbie fluvioglaciali. La Serra d'Ivrea è una morena frontale. Falda tipicamente assente fino a 5-10m. Numerose indagini per industria e residenziale nell'area ex-Olivetti.",
      numProveStimate: "120+",
      fontiSpecifiche: [
        { nome: "IdroGEO ISPRA — Comuni Canavese", url: "https://idrogeo.isprambiente.it/app/regione/PIEMONTE" },
        { nome: "Foglio CARG 142 Ivrea", url: "https://www.isprambiente.gov.it/Media/carg/142_IVREA/Foglio.html" }
      ]
    },
    "Valle Susa": {
      descrizione: "La Valle di Susa è incisa nella catena alpina con substrato cristallino e metamorfico (gneiss, micascisti, calcescisti). I fondivalle presentano depositi alluvionali della Dora Riparia e terrazzamenti antichi. Versanti con depositi detritici, conoidi torrentizi e fenomeni di instabilità. Disponibili studi per linea ferroviaria TAV Torino-Lione e numerose gallerie stradali.",
      numProveStimate: "200+",
      fontiSpecifiche: [
        { nome: "TELT — Studi geologici TAV", url: "https://www.telt-sas.com/it/news/documents/technical-documents/" },
        { nome: "Foglio CARG 154 Susa", url: "https://www.isprambiente.gov.it/Media/carg/154_SUSA/Foglio.html" },
        { nome: "SIFRaP ARPA — Valle Susa", url: "https://sifrap.arpa.piemonte.it/" }
      ]
    },
    "Pinerolese": {
      descrizione: "Il Pinerolese comprende la pianura di Pinerolo su alluvioni del Chisone e del Pellice, e le valli alpine (Val Pellice, Val Chisone, Val Germanasca) con substrato cristallino e metamorfico. Rischio frana significativo sui versanti. Disponibili indagini per piani regolatori di Pinerolo, Torre Pellice, Luserna San Giovanni.",
      numProveStimate: "80+",
      fontiSpecifiche: [
        { nome: "Foglio CARG 174 Pinerolo", url: "https://www.isprambiente.gov.it/Media/carg/174_PINEROLO/Foglio.html" },
        { nome: "ARPA Piemonte — Frane Pinerolese", url: "https://www.arpa.piemonte.it/temi/geologia-dissesto/frane-dissesto" }
      ]
    },
    "Pianura Torinese": {
      descrizione: "La pianura torinese è impostata su depositi alluvionali del Po e dei suoi affluenti (ghiaie, sabbie, limi) di età olocenica e pleistocenica. Falda freatica superficiale (2-8m). Rischio alluvionale significativo nelle fasce PAI. Disponibili numerose indagini per poli industriali, logistici e residenziali.",
      numProveStimate: "300+",
      fontiSpecifiche: [
        { nome: "BDGE — Pianura Padana Torinese", url: "https://www.geoportale.piemonte.it/geocatalogo/" },
        { nome: "PAI AdBPo — Fasce Po", url: "https://pai.adbpo.it/" }
      ]
    },
    "Valli Lanzo": {
      descrizione: "Le Valli di Lanzo (Stura di Lanzo) presentano substrato cristallino con gneiss e graniti del Massiccio del Lanzo. Depositi di versante, conoidi torrentizi e depositi fluvioglaciali nelle confluenze. Rischio frana elevato nelle valli strette. Dati più scarsi rispetto alle zone più urbanizzate.",
      numProveStimate: "40+",
      fontiSpecifiche: [
        { nome: "BDGE — Comuni Valli Lanzo", url: "https://www.geoportale.piemonte.it/geocatalogo/" },
        { nome: "SIFRaP ARPA — Valli Lanzo", url: "https://sifrap.arpa.piemonte.it/" }
      ]
    },
    "Valli Orco Soana": {
      descrizione: "Le Valli Orco e Soana sono valli alpine profonde con substrato cristallino (gneiss, graniti). Versanti molto acclivi con frane attive e quiescenti, conoidi di deiezione dei torrenti. Falda tipicamente assente o molto profonda. Dati geotecnici limitati alle aree di fondovalle con insediamenti.",
      numProveStimate: "20+",
      fontiSpecifiche: [
        { nome: "SIFRaP ARPA — Alta Valle Orco", url: "https://sifrap.arpa.piemonte.it/" },
        { nome: "ARPA — Monitoraggio frane alta valle", url: "https://www.arpa.piemonte.it/temi/geologia-dissesto/monitoraggio-frane" }
      ]
    },
    "Collina Torinese": {
      descrizione: "La Collina Torinese è costituita da depositi marini pliocenici (argille, marne, sabbie) e da conglomerati e ghiaie quaternarie. Morfologia collinare con versanti moderati soggetti a fenomeni di soliflussione e scivolamenti superficiali. Numerose indagini per insediamenti residenziali collinari.",
      numProveStimate: "90+",
      fontiSpecifiche: [
        { nome: "Foglio CARG 156 Torino Est", url: "https://www.isprambiente.gov.it/Media/carg/156_TORINO_EST/Foglio.html" },
        { nome: "BDGE — Collina Torinese", url: "https://www.geoportale.piemonte.it/geocatalogo/" }
      ]
    }
  }
};

// Mappa ISTAT → URL IdroGEO per link diretto dal modale indagini
function getIdroGeoUrl(istat) {
  return `https://idrogeo.isprambiente.it/app/comune/IT${istat}`;
}

// Link al foglio CARG in base alle coordinate
function getCARGFoglioUrl(lat, lng) {
  // Assegnazione approssimativa per zona
  if (lng < 7.2) return { nome: "F. 154 Susa", url: "https://www.isprambiente.gov.it/Media/carg/154_SUSA/Foglio.html" };
  if (lng < 7.5 && lat < 45.0) return { nome: "F. 174 Pinerolo", url: "https://www.isprambiente.gov.it/Media/carg/174_PINEROLO/Foglio.html" };
  if (lat > 45.35) return { nome: "F. 142 Ivrea", url: "https://www.isprambiente.gov.it/Media/carg/142_IVREA/Foglio.html" };
  if (lng > 7.75) return { nome: "F. 156 Torino Est", url: "https://www.isprambiente.gov.it/Media/carg/156_TORINO_EST/Foglio.html" };
  return { nome: "F. 155 Torino Ovest", url: "https://www.isprambiente.gov.it/Media/carg/155_TORINO_OVEST/Foglio.html" };
}
