#!/bin/bash
# ============================================================
# RiskMap TO — Build Eseguibile Desktop
# Crea installer per Windows (.exe), macOS (.dmg), Linux (.AppImage)
# 
# PREREQUISITI:
#   - Node.js >= 16 (nodejs.org)
#   - npm (incluso con Node.js)
#   - Connessione internet (per scaricare Electron ~100MB)
# 
# USO:
#   chmod +x build.sh
#   ./build.sh
# ============================================================

set -e

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║   🗺  RiskMap TO — Build Eseguibile          ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

# Verifica Node.js
if ! command -v node &> /dev/null; then
    echo "  ✗ Node.js non trovato. Installa da https://nodejs.org"
    exit 1
fi
echo "  ✓ Node.js: $(node --version)"
echo "  ✓ npm: $(npm --version)"

# Installa dipendenze
echo ""
echo "  📦 Installazione dipendenze (Electron + electron-builder)…"
echo "     (Può richiedere 2-5 minuti — download ~100MB)"
echo ""
npm install

echo ""
echo "  🔨 Scelta piattaforma di build:"
echo "     1) Windows (.exe installer NSIS)"
echo "     2) macOS (.dmg)"  
echo "     3) Linux (.AppImage)"
echo "     4) Tutte le piattaforme"
echo "     5) Solo avvio locale (npm start — senza build)"
echo ""
read -p "  Scelta [1-5]: " choice

case $choice in
    1)
        echo "  🪟 Build Windows…"
        npm run build:win
        echo "  ✓ Eseguibile: dist/RiskMap TO Setup *.exe"
        ;;
    2)
        echo "  🍎 Build macOS…"
        npm run build:mac
        echo "  ✓ Eseguibile: dist/RiskMap TO *.dmg"
        ;;
    3)
        echo "  🐧 Build Linux…"
        npm run build:linux
        echo "  ✓ Eseguibile: dist/RiskMap TO *.AppImage"
        ;;
    4)
        echo "  🌍 Build tutte le piattaforme…"
        npm run build:all
        echo "  ✓ Eseguibili in: dist/"
        ;;
    5)
        echo "  🚀 Avvio locale…"
        npm start
        exit 0
        ;;
    *)
        echo "  Scelta non valida."
        exit 1
        ;;
esac

echo ""
echo "  ✅ Build completata! Gli eseguibili si trovano nella cartella dist/"
echo ""
echo "  NOTA: Dopo l'installazione, per usare la generazione AI:"
echo "  Avvia l'app → Menu → File → Configura API Key Anthropic"
echo "  (API key ottenibile su https://console.anthropic.com)"
echo ""
