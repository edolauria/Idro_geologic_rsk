/**
 * RiskMap TO — Server locale con proxy API Anthropic
 * Risolve il problema CORS quando l'app viene aperta come file://
 * 
 * AVVIO:
 *   node server.js
 *   (poi apri http://localhost:3000)
 * 
 * REQUISITI: Node.js >= 14 (nessun pacchetto npm necessario)
 * 
 * CONFIGURAZIONE API KEY:
 *   Windows:  set ANTHROPIC_API_KEY=sk-ant-...
 *   Mac/Linux: export ANTHROPIC_API_KEY=sk-ant-...
 *   oppure modifica direttamente la riga API_KEY qui sotto
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 3000;
// API key letta a ogni richiesta — funziona anche se impostata DOPO l'avvio del server
// Puoi anche incollarla direttamente qui sotto come stringa tra virgolette:
let API_KEY_OVERRIDE = ''; // es: let API_KEY_OVERRIDE = 'sk-ant-api03-...';
function getApiKey() { return API_KEY_OVERRIDE || process.env.ANTHROPIC_API_KEY || ''; }

// MIME types per i file statici
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.txt':  'text/plain; charset=utf-8',
};

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url);

  // ─── CORS headers per tutte le risposte ───
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-api-key, anthropic-version, anthropic-dangerous-direct-browser-access');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // ─── PROXY → api.anthropic.com ───
  if (parsedUrl.pathname === '/api/anthropic' && req.method === 'POST') {
    if (!getApiKey()) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        error: { message: 'ANTHROPIC_API_KEY non configurata. Leggi le istruzioni in cima a server.js' }
      }));
      return;
    }

    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const options = {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': getApiKey(),
          'anthropic-version': '2023-06-01',
          'Content-Length': Buffer.byteLength(body)
        }
      };

      const proxyReq = https.request(options, proxyRes => {
        let data = '';
        proxyRes.on('data', chunk => data += chunk);
        proxyRes.on('end', () => {
          res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json' });
          res.end(data);
        });
      });

      proxyReq.on('error', err => {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: `Errore connessione Anthropic: ${err.message}` } }));
      });

      proxyReq.write(body);
      proxyReq.end();
    });
    return;
  }

  // ─── SALVA FILE .tex SU DISCO ───
  if (parsedUrl.pathname === '/api/salva-tex' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { nomeFile, contenuto } = JSON.parse(body);

        // Validazione nome file: solo caratteri sicuri
        if (!nomeFile || !/^[a-zA-Z0-9_\-\.]+\.tex$/.test(nomeFile)) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Nome file non valido' }));
          return;
        }
        if (!contenuto || typeof contenuto !== 'string') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Contenuto mancante' }));
          return;
        }

        // Crea cartella output/ se non esiste
        const outputDir = path.join(__dirname, 'output');
        if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

        const filePath = path.join(outputDir, nomeFile);
        fs.writeFile(filePath, contenuto, 'utf-8', (err) => {
          if (err) {
            console.error('[salva-tex] Errore scrittura:', err.message);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: err.message }));
          } else {
            console.log(`[salva-tex] Salvato: output/${nomeFile}`);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, percorso: `output/${nomeFile}` }));
          }
        });
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'JSON non valido' }));
      }
    });
    return;
  }

  // ─── FILE STATICI ───
  let filePath = path.join(__dirname, parsedUrl.pathname === '/' ? 'index.html' : parsedUrl.pathname);

  // Sicurezza: impedisce path traversal
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end(`File non trovato: ${parsedUrl.pathname}`);
      } else {
        res.writeHead(500); res.end('Errore server');
      }
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════════════════╗');
  console.log('  ║   🗺  RiskMap TO — Rischio Idrogeologico Torino      ║');
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log(`  ║   Server attivo su  →  http://localhost:${PORT}         ║`);
  console.log(`  ║   API Key:  ${getApiKey() ? '✓ configurata' : '✗ MANCANTE — AI non funzionerà '}             ║`);
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log('  ║   Per configurare la API key:                        ║');
  console.log('  ║   Mac/Linux: export ANTHROPIC_API_KEY=sk-ant-...     ║');
  console.log('  ║   Windows:   set ANTHROPIC_API_KEY=sk-ant-...        ║');
  console.log('  ║   poi riavvia: node server.js                        ║');
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log('  ║   File .tex salvati in:  ./output/                   ║');
  console.log('  ╚══════════════════════════════════════════════════════╝');
  console.log('');
  if (!getApiKey()) {
    console.log('  ⚠  ATTENZIONE: API key non trovata. La generazione di relazioni');
    console.log('     geologiche e predizioni AI non sarà disponibile.\n');
  }
});
